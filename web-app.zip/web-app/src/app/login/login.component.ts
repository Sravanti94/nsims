import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserService } from '../_services/index';
import { Global } from './../global';
import { NgForm } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'my-login',
    templateUrl: './login.component.html',
    providers: [AuthenticationService,  UserService],
})

// create class for login.
export class LoginComponent implements OnInit {

    model: any = {};
    loading: boolean = false;
    error: string = '';
    serviceCalled: boolean = false;
    loginMsg: string = '';
    passwordMsg: string = '';
    forgotMsg: string = '';
    forgotErrMsg: string = '';
    global: any = Global;
    show: boolean = false;
    encurl: string = '';
    requesttime: number;
    private sub: any;
    current_time: number;
    elapsedTimeStamp: number;
    elapsedTime: number;
    maxtime: number;
    currentUrl: any = '';
    hide: boolean = false;
    ResetPasswordForm: boolean = false;
    loginForm: boolean = false;
    ForgotPasswordForm: boolean = false;
    showMsg: boolean = false;
    hidemsg: boolean = false;
    id: number;
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService,
        private userService: UserService,
        private route: ActivatedRoute) {}

    // Iterates through the list of champions adding them to the current object
    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            if (Object.keys(params).length) {
                this.encurl  = params['encrypturl'];
                this.userService.decrypturl(this.encurl)
                .subscribe(result => {
                    this.id = result.content['id'];
                    this.requesttime  = result.content['request_time'];
                    this.current_time = Math.floor(Date.now() / 1000);
                    this.elapsedTimeStamp = this.current_time - this.requesttime;
                    this.elapsedTime = this.elapsedTimeStamp / 60;
                    this.maxtime = 30;
                });
            }
        });
        // if url comes enable resetpassword name.
        if (this.encurl) {
            this.showResetPassword();
        }else {
            this.showlogin();
        }
     }

    // Add new Login details
    login() {
        this.loading = true;
        this.authenticationService.login(this.model.username, this.model.password)
        .subscribe(result => {
            this.serviceCalled = true;
            if (result === true) {
                let retrievedData = localStorage.getItem('currentUser');
                if (retrievedData) {
                    let userdata = JSON.parse(retrievedData);
                    if (parseInt(userdata.user_role_id, 0) === Global.role.superAdmin) {
                        // navigate to superadmin dashboard
                        this.showMsg = false;
                        this.router.navigate(['/dashboard/s']);
                        return false;
                    } else if (parseInt(userdata.user_role_id, 0) === Global.role.primary) {
                        // navigate to primary dashboard
                        this.showMsg = false;
                        this.router.navigate(['/dashboard/p']);
                        return false;
                    } else if (parseInt(userdata.user_role_id, 0) === Global.role.secondary) {
                        // navigate to secondary dashboard
                        this.showMsg = false;
                        this.router.navigate(['/dashboard/se']);
                        return false;
                    }
                }
            this.loading = false;
            } else {
                this.showMsg = false;
                this.loginMsg = result.msg;
                this.error = result.stat;
                this.error = 'Username or password is incorrect';
                this.loading = false;
            }
        });
    }
    // show only password reset
    showResetPassword() {
        this.ResetPasswordForm = true;
        this.loginForm = false;
        this.ForgotPasswordForm = false;
    }
    // show only the forget password form.
    showForgotPassword() {
        this.ResetPasswordForm = false;
        this.loginForm = false;
        this.ForgotPasswordForm = true;
    }
    // show only login.
    showlogin() {
        this.ResetPasswordForm = false;
        this.loginForm = true;
        this.ForgotPasswordForm = false;
    }
    // Request for new password
    forgotpassword(fp: NgForm) {
        this.loading = true;
        this.userService.forgotpassword(this.model)
        .subscribe(result => {
            this.serviceCalled = true;
            if (result.stat === true) {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                // this.alertService.success('Registration successful', true);
                this.forgotMsg = result.msg[0];
                this.error = result.stat;
                // this.router.navigate(['/login']);
                this.loading = false;
                fp.resetForm();
            } else {
                this.forgotErrMsg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }

    // Reset your password
    resetPassword() {
        this.show = false;
        this.loading = true;
        this.userService.resetPassword(this.model, this.id)
        .subscribe(result => {

            this.serviceCalled = true;
            if (result.stat === true) {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                // this.alertService.success('Registration successful', true);
                this.passwordMsg = result.msg[0];
                this.error = result.stat;
                this.showMsg = true;
                this.showlogin();
                this.loading = false;
            } else {
                this.passwordMsg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
}
