import { Component, OnInit } from '@angular/core';
import { Global } from './../global';
// import { WarehouseService } from '../_services/index';
import { apiUrl } from './../global';


@Component({
  selector: 'my-pa',
  templateUrl: './primaryaccount.component.html',
//  providers: [ WarehouseService ]
  // styleUrls: ['./about.component.scss']
})
export class PrimaryAccountComponent implements OnInit {
    // @maheshPerla: the below link used to trigger the inline edit save  to call the api
    // https://github.com/akveo/ng2-smart-table/issues/284
    userData: any;
    global: any = Global;
    data: any;
    column: any = [];
    row: any = [];
    table_data: any = [];
    Object = Object;
    price_data: any;
    price_column: any = [];
    pl_column: any = [];
    price_date: any;
    pl_date: any;
    count_date: any;
    dashboard: any = {};
    date: any = new Date().toISOString().slice(0, 10);
    month_year: any = new Date().toISOString().slice(0, 7);
    pl_data: any = {};
    ss_data: any = {};
    ss_column: any = [];
    ss_date: any;
    msg: any;
    url: any = apiUrl;
    filename: any;
    pl: boolean = false;
    ss: boolean = false;
    constructor(
       // private WarehouseService: WarehouseService
    ) {
    // Do stuff
    }
  // Iterates through the list of champions adding them to the current object
    ngOnInit() {
        this.global.layout.title = 'Welcome to Dashboard';
        this.global.layout.breadCrumb = 'Dashboard';
        this.global.layout.cardTilte = 'Dashboard';

        let retrievedData = localStorage.getItem('currentUser');
            if (retrievedData) {
               this.userData = JSON.parse(retrievedData);
            }
            /*this.stockCountReport(this.date);
            this.stockValueReport(this.date);
            this.profitLossReportPerMonth(this.month_year);
            this.secondarySalesReportPerMonth(this.month_year);*/
    }
    /*// to create sell count report.
    stockCountReport(date) {
        this.column = [];
        this.data = [];
        this.count_date = date;
        this.WarehouseService.primaryStockCountReport(this.userData.user_id, date)
            .subscribe(result => {
                this.data = result.content;
                let dat: any;
                for (dat in this.data[0]) {
                    if (this.data[0].hasOwnProperty(dat)) {
                        dat = dat.replace('_', ' ');
                        dat = dat.toUpperCase();
                        this.column.push(dat);
                    }
                }
        });
    }
    // to create sell price report.
    stockValueReport(date) {
        this.price_column = [];
        this.price_data = [];
        this.price_date = date;
        this.WarehouseService.primaryStockValueReport(this.userData.user_id, date)
            .subscribe(result => {
                this.price_data = result.content;
                let dat: any;
                for (dat in this.price_data[0]) {
                    if (this.price_data[0].hasOwnProperty(dat)) {
                        dat = dat.replace('_', ' ');
                        dat = dat.toUpperCase();
                        this.price_column.push(dat);
                    }
                }
        });
    }
    // to create sell price report.
    profitLossReportPerMonth(date) {
        this.pl_column = [];
        this.pl_data = [];
        this.pl_date = date;
        this.pl = false;
        this.WarehouseService.primaryProfitLossReportPerMonth(this.userData.user_id, date)
            .subscribe(result => {
                this.pl_data = result.content;
                this.msg = result.msg;
                this.filename = result.msg;
                if (result.stat === true) {
                    this.pl = true;
                }
                let dat: any;
                for (dat in this.pl_data[0]) {
                    if (this.pl_data[0].hasOwnProperty(dat)) {
                        dat = dat.replace('_', ' ');
                        dat = dat.toUpperCase();
                        this.pl_column.push(dat);
                    }
                }
        });
    }
    // to create sell price report.
    secondarySalesReportPerMonth(date) {
        this.ss_column = [];
        this.ss_data = [];
        this.ss_date = date;
        this.ss = false;
        this.WarehouseService.primarySecondarySalesReportPerMonth(this.userData.user_id, date)
            .subscribe(result => {
                this.ss_data = result.content;
                this.msg = result.msg;
                this.filename = result.msg;
                let dat: any;

                if (result.stat === true) {
                    this.ss = true;
                }
                for (dat in this.ss_data[0]) {
                    if (this.ss_data[0].hasOwnProperty(dat)) {
                        dat = dat.replace('_', ' ');
                        dat = dat.toUpperCase();
                        this.ss_column.push(dat);
                    }
                }
        });
    }*/
}
