import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { AuthenticationService } from '../_services/index';
import { Global } from './../global';

@Component({
  selector: 'my-dashboard',
  templateUrl: './dashboardLayout.component.html',
  styleUrls: ['./dashboardLayout.component.scss']
  // providers: [AuthenticationService],
})
export class DashboardLayoutComponent implements OnInit {

    userData: string;
    loading = false;
    error = '';
    clicked: string = null;
    global: any = Global;
    showMenu: boolean = false;
    syncMenu: boolean = false;
  // In a real app: load the details here in  `ngOnInit` method
  ngOnInit() {
    // this.authenticationService.logout();
    // this.router.navigate(['/']);
    let retrievedData = localStorage.getItem('currentUser');
    if (retrievedData) {
      this.userData = JSON.parse(retrievedData);
   }
 }

  navigationClick(clicked: string): void {
    this.clicked = this.clicked === clicked ? null : clicked;
  }

  /*createlogistics() {
       this.loading = true;
       this.LogisticsService.createLogistics(this.logistics.name, this.logistics.city)
            .subscribe(result => {
              console.log(result);
                if (result === true) {
                    this.router.navigate(['/about']);
                } else {
                    this.error = 'Username or password is incorrect';
                    this.loading = false;
                }
            });
  }*/

  showMenuItem() {
    if (this.showMenu) {
      this.showMenu = false;
    } else {
      this.showMenu = true;
    }
  }

  showSyncMenu() {
    if (this.syncMenu) {
      this.syncMenu = false;
    } else {
      this.syncMenu = true;
    }
  }

  overSync() {
    this.syncMenu = true;
  }

  overMenu() {
    this.showMenu = true;
  }
}
