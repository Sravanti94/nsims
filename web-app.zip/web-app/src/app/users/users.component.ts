import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
    selector: 'my-brand',
    templateUrl: './users.component.html',
    providers: [AuthenticationService, UserService],
})
export class UsersComponent implements OnInit {
    settings = {
        mode: 'external',
        columns: {
           first_name: {
                title: 'Name',
                type: 'custom',
                renderComponent: CustomRenderComponent,
            },
            email: {
                title: 'Email',
                type: 'custom',
                renderComponent: CustomRenderComponent,
            },
            mobile: {
                title: 'Mobile',
                type: 'custom',
                renderComponent: CustomRenderComponent,
            }
        },
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            position: 'right',
        },
        edit: {
          editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
          deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    user: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    private UserService: UserService) { }
    // implement OnInit's `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'User List';
        this.global.layout.breadCrumb = 'User List';
        this.global.layout.cardTilte = 'Dashboard Layout';

        this.UserService.listPrimaryUser(this.global.paginator.getRows, this.global.paginator.rows, this.global.paginator.defaultPage)
        .subscribe(result => {

            if ( result !== false) {
                this.user = result.content;
                this.source = new LocalDataSource(this.user);
            }
            return true;
        });
    }
   // redirect to profile edit.
    editPreleveur(rowData) {
        this.router.navigate(['/users/profile/' + rowData.data.id]);
    }
    // change the status to delete.
    deletePreleveur(rowData) {
        if (window.confirm('Are you sure you want to delete?')) {
         this.UserService.deleteUser(rowData.data.id)
        .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
        } else {
            Promise.reject('cancled').then(function(error) {
                return error;
            }, function(error) {
                return error;
            });
        }
    }

}
