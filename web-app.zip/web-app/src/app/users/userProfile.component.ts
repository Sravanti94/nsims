    import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { ActivatedRoute } from '@angular/router';
import { StatusService } from '../_services/index';

@Component({
    selector: 'my-user',
    templateUrl: './userProfile.component.html',
    providers: [AuthenticationService, UserService, StatusService],
})
export class UserProfileComponent implements OnInit {
    settings = {
        mode: 'external',
        columns: {
           first_name: {
                title: 'Name',
            },
            email: {
                title: 'Email',
            },
            mobile: {
                title: 'Mobile',
            }
        },
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            position: 'right',
        },
        edit: {
          editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
          deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    secondaryUser: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    global: any = Global;
    id: number;
    private sub: any;
    primaryUser: any = {};
    statuses: any;
    serviceCalled: boolean = true;
    msg: string = '';
    error_msg = false;
    secondaryAccounts: boolean = false;
    totalCount: number;

    constructor(
    private router: Router,
    private UserService: UserService,
    private route: ActivatedRoute,
    private StatusService: StatusService) { }

    // implement OnInit's `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Edit User Profile';
        this.global.layout.breadCrumb = 'Edit User Profile';
        this.global.layout.cardTilte = 'Dashboard Layout';

        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });
        this.StatusService.listStatusId()
        .subscribe(result => {
            this.statuses = result.content;
        });    

        this.UserService.getUserById(this.id)
        .subscribe(result => {
            if ( result !== false) {
                this.primaryUser = result.content;
            }
            return true;
        });
    }

   // redirect to user edit.
    editPreleveur(rowData) {
        this.secondaryAccounts = false;
        this.router.navigate(['/user/profile/' + rowData.data.id]);
    }

    updateProfile() {
        this.loading = true;
        this.UserService.profile(this.primaryUser)
            .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                if (this.primaryUser.role_id === 3) {
                    this.router.navigate(['/users']);
                } else {
                    this.router.navigate(['/users/profile/' + this.primaryUser.parent_id]);
                }
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;

            }
        });

    }

    // change the status to delete.
    deletePreleveur(rowData) {
        if (window.confirm('Are you sure you want to delete?')) {
         this.UserService.deleteUser(rowData.data.id)
        .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
        } else {
            Promise.reject('cancled').then(function(error) {
            return error;
        }, function(error) {
            return error;
        });
    }
    }
    close () {
        this.serviceCalled = false;
    }

}
