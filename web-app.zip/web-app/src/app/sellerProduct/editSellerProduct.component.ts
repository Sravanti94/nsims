import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { SellerProductService } from '../_services/index';
import { StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-product',
    templateUrl: './editSellerProduct.component.html',
    providers: [SellerProductService , StatusService]
})
export class EditSellerProductComponent implements OnInit, OnDestroy {
    sellerproduct: any = {};
    loading = false;
    error = '';
    id: number;
    retrievedData: any;
    userData: any;
    private sub: any;
    statuses: any;
    products: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = false;
    constructor(
    private router: Router,
    private SellerProductService: SellerProductService,
    private route: ActivatedRoute,
    private StatusService: StatusService) {}
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Your Product';
        this.global.layout.breadCrumb = 'Edit Product';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });

        this.SellerProductService.getSellerProduct(this.id)
        .subscribe(result => {
            if ( result !== false) {
                this.sellerproduct = JSON.parse(result);
            }
            return true;
        });

        this.StatusService.listStatusId()
        .subscribe(result => {
            this.statuses = result.content;
        });
    }

    // destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // edit new seller details in 'nt_seller_product'
    editSellerProduct() {
        this.loading = true;
        this.SellerProductService.editSellerProduct(this.sellerproduct, this.userData)
        .subscribe(result => {

            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/your-products']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }

    close () {
        this.serviceCalled = false;
    }
}
