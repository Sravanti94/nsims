import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../_services/index';
import { SellerProductService } from '../_services/index';
import { CategoryService, BrandService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-poduct',
    templateUrl: './addSellerProduct.component.html',
    providers: [ProductService, SellerProductService, CategoryService, BrandService ],
   })
export class AddSellerProductComponent implements OnInit {
    userData: any;
    sellerproduct: any = {};
    loading = false;
    error = '';
    retrievedData: any;
    products: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    product_id: number = 0;
    error_msg = false;
    categories: any;
    category: number;
    level = 0;
    childCategory: any = [];
    last = false;
    next = false;
    row: any = [];
    data: any = [];
    brand_id: number = 0;
    brands: any;
    constructor(
    private router: Router,
    private ProductService: ProductService,
    private SellerProductService: SellerProductService,
    private CategoryService: CategoryService,
    private BrandService: BrandService,
    ) {}
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Your Product';
        this.global.layout.breadCrumb = 'Add Product';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.ProductService.listActiveProduct(this.product_id)
        .subscribe(result => {
            this.products = result.content;
        });
        this.CategoryService.listCategoryParent()
        .subscribe(result => {
            if (Object.keys(result.content).length !== 0) {
                this.categories = result.content;
                this.childCategory.push(this.categories);
            }
        });
    }

    // to show the child categories after selecting category
    onchange(category_id, index) {
        this.category = category_id;
        this.level = index;
        this.serviceCalled = false;
        this.error_msg = false;
        this.CategoryService.listCategoryByParentId(category_id)
        .subscribe(result => {
            if (Object.keys(result.content).length !== 0) {
                this.categories = result.content;
                // pop elements after that index
                this.childCategory.splice(this.level + 1, this.childCategory.length);
                this.childCategory.push(this.categories);
                this.last = false;
            }else {
                this.childCategory.splice(this.level + 1, this.childCategory.length);
                this.BrandService.listBrandByCategory(category_id, this.brand_id)
                .subscribe(resultBrand => {
                    if (resultBrand.stat === true) {
                        this.brands = resultBrand.content;
                        this.last = true;
                    } else {
                        this.serviceCalled = true;
                        this.error_msg = true;
                        this.msg = resultBrand.msg[0];
                        this.error = resultBrand.stat;
                    }
                });
            }
        });
        this.next = false;
        this.loading = false;
        this.sellerproduct.product_id = [];
    }

    // Show the list of products under selected brand
    productList(brand_id) {
        this.sellerproduct.product_id = [];
        this.ProductService.listActiveProductByBrand(brand_id, this.userData.user_id, this.category
            )
            .subscribe(result => {
                if (result.stat === true) {
                    this.products = result.content;
                    this.next = true;
                    this.serviceCalled = false;
                } else {
                    this.serviceCalled = true;
                    this.error_msg = true;
                    this.msg = result.msg[0];
                    this.error = result.stat;
                    this.next = false;
                }
            });
    }

    // Add new seller products in 'nt_seller_product'
    addSellerProduct() {
        this.loading = true;
        if (this.sellerproduct.product_id.length) {
            this.SellerProductService.addSellerProduct(this.sellerproduct, this.userData)
            .subscribe(result => {
                this.serviceCalled = true;

                if (result.stat === true) {
                    this.msg = result.msg[0];
                    this.router.navigate(['/your-products']);
                    this.loading = false;
                } else {
                    this.serviceCalled = true;
                    this.error_msg = true;
                    this.msg = result.msg;
                    this.error = result.stat;
                    this.loading = false;
                }

            });
        } else {
            this.serviceCalled = true;
            this.error_msg = true;
            this.msg = 'Please select at least one Product';
            this.loading = false;
        }
    }
	// to close the message flag
    close () {
        this.serviceCalled = false;
    }

}
