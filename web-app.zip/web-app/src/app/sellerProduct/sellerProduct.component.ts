import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SellerProductService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
    selector: 'my-product',
    templateUrl: './sellerProduct.component.html',
    providers: [SellerProductService],
})
export class SellerProductComponent implements OnInit {
    settings = {
        mode: 'external',
        columns: {
           product_name: {
              title: 'Name',
              width: '250px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            product_code: {
              title: 'Product Code',
              width: '180px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            product_sku: {
              title: 'SKU',
              width: '400px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            category_name: {
              title: 'Category',
              width: '180px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            brand_name: {
              title: 'Brand',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            color: {
              title: 'Color',
              width: '100px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            size_type_name: {
              title: 'Size Type',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            size: {
              title: 'Size',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            status_name: {
              title: 'Status',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            }
        },
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: true,
            position: 'right',
        },
        pager: {
            display: false,
        },
        edit: {
            editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
            deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    sellerproduct: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    retrievedData: any;
    userData: any;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    private SellerProductService: SellerProductService) { }
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Your Product List';
        this.global.layout.breadCrumb = 'Your Product List';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.SellerProductService.listSellerProduct(this.userData.user_id, this.global.paginator.getRows, this.global.paginator.rows,
            this.global.paginator.defaultPage)
        .subscribe(result => {

            if ( result !== false) {
                this.sellerproduct = JSON.parse(result);
                this.source = new LocalDataSource(this.sellerproduct);
            }
            return true;
        });
    }
    // Redirecting to edit 'nt_seller_product'.
    editPreleveur(rowData) {
        this.router.navigate(['/your-products/edit/' + rowData.data.id]);
    }
    // Delete data from seller product list.
    deletePreleveur(rowData) {
        if (window.confirm('Are you sure you want to delete?')) {
            this.SellerProductService.deletesellerproduct(rowData.data.id)
            .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
    } else {
        Promise.reject('cancled').then(function(error) {
            return error;
        }, function(error) {
            return error;
        });
    }
}
    // Redirecting to add seller product.
    clicked() {
        this.router.navigate(['/your-products/add']);
    }
}
