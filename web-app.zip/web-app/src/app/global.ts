import { Injectable } from '@angular/core';

Injectable();
export var Global = Object.freeze({

    pageTitle: 'Newtel - Inventory Management System',
    metaKeyword: '',
    metaDescription: '',
    layout: {
        title: '',
        breadCrumb: '',
        cardTilte: '',
    },
    role: {
        superAdmin: 1,
        primary: 3,
        secondary: 4,
    },
    image: {
        load: 'data:image/gif;base64,R0lGODlhEAAQAPIAAP///wAAAMLCwkJCQgAAAGJiYoKCgpKSkiH/C05FVFNDQVBFMi4wAwEAAAAh/hpDcmVhdGVkIHdpdGggYWpheGxvYWQuaW5mbwAh+QQJCgAAACwAAAAAEAAQAAADMwi63P4wyklrE2MIOggZnAdOmGYJRbExwroUmcG2LmDEwnHQLVsYOd2mBzkYDAdKa+dIAAAh+QQJCgAAACwAAAAAEAAQAAADNAi63P5OjCEgG4QMu7DmikRxQlFUYDEZIGBMRVsaqHwctXXf7WEYB4Ag1xjihkMZsiUkKhIAIfkECQoAAAAsAAAAABAAEAAAAzYIujIjK8pByJDMlFYvBoVjHA70GU7xSUJhmKtwHPAKzLO9HMaoKwJZ7Rf8AYPDDzKpZBqfvwQAIfkECQoAAAAsAAAAABAAEAAAAzMIumIlK8oyhpHsnFZfhYumCYUhDAQxRIdhHBGqRoKw0R8DYlJd8z0fMDgsGo/IpHI5TAAAIfkECQoAAAAsAAAAABAAEAAAAzIIunInK0rnZBTwGPNMgQwmdsNgXGJUlIWEuR5oWUIpz8pAEAMe6TwfwyYsGo/IpFKSAAAh+QQJCgAAACwAAAAAEAAQAAADMwi6IMKQORfjdOe82p4wGccc4CEuQradylesojEMBgsUc2G7sDX3lQGBMLAJibufbSlKAAAh+QQJCgAAACwAAAAAEAAQAAADMgi63P7wCRHZnFVdmgHu2nFwlWCI3WGc3TSWhUFGxTAUkGCbtgENBMJAEJsxgMLWzpEAACH5BAkKAAAALAAAAAAQABAAAAMyCLrc/jDKSatlQtScKdceCAjDII7HcQ4EMTCpyrCuUBjCYRgHVtqlAiB1YhiCnlsRkAAAOwAAAAAAAAAAAA==',
    },
    version: {
        name: 'v 1.0.1',
    },
    paginator: {
        rows: 10,
        perPageOptions: [10, 25, 50],
        defaultPage: 0,
        getCount: 1,
        getRows: 0,
    },
    stock_status: {
        intransit: 1,
        inward: 2,
        rejected: 3,
        recallGood: 4,
        recallBad: 5,
        Lost: 6,
        inTransit: 7,
        delivered: 8,
        lost: 9,
        courierReturnedGood: 10,
        courierReturnedBad: 11,
        reCall: 12
    },
    kaya: {
      demoUserId: 44,
    },

    redirect(url) {
       url = '/#' + url;
       if (window.confirm(' You will lose all unsaved modifications. Are you sure that you`d like to proceed?')) {
          window.location.assign(url);
          // this.router.navigate([url]);
           return false;
       } else {
           Promise.reject('cancled').then(function(error) {
               return error;
           }, function(error) {
               return error;
           });
       }
   }
});

var API_URL: string = "http://local.ns_ims_app.com";
export const apiUrl = API_URL;
