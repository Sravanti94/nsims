import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SizeTypeService, SizeTypeCategoryService } from '../_services/index';
import { CategoryService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-sizetypecategory',
    templateUrl: './addSizeTypeCategory.component.html',
    providers: [CategoryService, SizeTypeService, SizeTypeCategoryService],
   })
export class AddSizeTypeCategoryComponent implements OnInit {

    sizetype: any = {};
    loading = false;
    error = '';
    categories: any;
    userData: any;
    retrievedData: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    sizetypes: any;
    sizetypecategory: any = {};
    category_id: number = 0;
    size_id: number = 0;
    error_msg = true;
    constructor(
    private router: Router,
    private SizeTypeCategoryService: SizeTypeCategoryService,
    private SizeTypeService: SizeTypeService,
    private CategoryService: CategoryService) {}
    // Iterates through the list adding them to the current object in 'ngoninit' method.

    ngOnInit() {
        this.global.layout.title = 'Category Size Type Mapping';
        this.global.layout.breadCrumb = 'Add Category Size Type ';
        this.global.layout.cardTilte = 'Dashboard Layout';

       this.CategoryService.listActiveLastChildCategory(this.category_id)
        .subscribe(result => {
            this.categories = JSON.parse(result);
        });
        this.SizeTypeService.activeSizeTypelist(this.size_id)
        .subscribe(result => {
            this.sizetypes = result.content;
        });
    }

    // Add new size type 'nt_size_type'
    addSizeTypeCategory() {
        this.global.layout.title = 'Size Type';
        this.global.layout.breadCrumb = 'Add Size Type';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.loading = true;
        this.SizeTypeCategoryService.addSizeTypeCategory(this.sizetypecategory.size_id, this.sizetypecategory.category_id,
                        this.sizetypecategory.status_id)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/category-sizetype-mapping']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }

        });
    }
    close() {
        this.serviceCalled = false;
    }

    onchange(size_type_id) {
        this.serviceCalled = false;
        // list the category which are not in the selected sizetype
        this.CategoryService.listRestChildCategory(size_type_id)
        .subscribe(result => {
            if (result.stat === true) {
                this.categories = result.content;
                this.loading = false;
            } else {
                this.categories = result.content;
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });

    }
}
