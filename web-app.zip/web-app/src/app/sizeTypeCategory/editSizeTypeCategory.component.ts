import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { SizeTypeService, SizeTypeCategoryService } from '../_services/index';
import { CategoryService } from '../_services/index';
import { StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-sizetypecategory',
    templateUrl: './editSizeTypeCategory.component.html',
    providers: [SizeTypeService , CategoryService , StatusService, SizeTypeCategoryService]
})
export class EditSizeTypeCategoryComponent implements OnInit, OnDestroy {
    sizetype: any = {};
    loading = false;
    error = '';
    id: number;
    private sub: any;
    categories;
    sizetypes;
    statuses;
    userData: any;
    retrievedData: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    sizetypecategory: any = {};
    error_msg = false;

    constructor(
    private router: Router,
    private SizeTypeService: SizeTypeService,
    private SizeTypeCategoryService: SizeTypeCategoryService,
    private route: ActivatedRoute,
    private CategoryService: CategoryService,
    private StatusService: StatusService) {}
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Category Size Type Mapping';
        this.global.layout.breadCrumb = 'Edit Category Size Type';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.sub = this.route.params.subscribe(params => {
        this.id = +params['id']; // (+) converts string 'id' to a number
        // In a real app: dispatch action to load the details here.
    });
    this.SizeTypeCategoryService.getSizeTypeCategory(this.id)
        .subscribe(result => {
            if ( result !== false) {
                this.sizetypecategory = JSON.parse(result);
            }
            this.SizeTypeService.activeSizeTypelist(this.sizetypecategory.size_id)
            .subscribe(resultSizeType => {
                this.sizetypes = resultSizeType.content;
            });
            this.CategoryService.listActiveLastChildCategory(this.sizetypecategory.category_id)
            .subscribe(resultCategory => {
                this.categories = JSON.parse(resultCategory);
            });
            return true;
        });
    this.StatusService.listStatusId()
    .subscribe(result => {
        if ( result !== false) {
            this.statuses = result.content;
        }
    });
}
    // Destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // Edit size Type from'nt_size_type'.
    editSizeTypeCategory() {
        this.loading = true;
        this.SizeTypeCategoryService.editSizeTypeCategory(this.sizetypecategory)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/category-sizetype-mapping']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
    close () {
        this.serviceCalled = false;
    }
}
