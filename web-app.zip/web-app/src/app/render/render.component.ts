import { Component, Input, OnInit } from '@angular/core';

import { ViewCell } from 'ng2-smart-table';

@Component({
  template: `
    {{renderValue}}
  `,
})
export class CustomRenderComponent implements ViewCell, OnInit {

    renderValue: any;

    @Input() value: string | number;
    @Input() rowData: any;

    ngOnInit() {
        if (this.value) {
            this.renderValue = this.value;
        } else {
            this.renderValue = '-';
        }
    }

}
