import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { BrandcategoryService } from '../_services/index';
import { CategoryService } from '../_services/index';
import { StatusService } from '../_services/index';
import { BrandService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-brandcategory',
    templateUrl: './editBrandCategory.component.html',
    providers: [BrandcategoryService , CategoryService , StatusService , BrandService]
})
export class EditBrandCategoryComponent implements OnInit, OnDestroy {
    brandcategory: any = {};
    error = '';
    loading = false;
    id: number;
    categories: any;
    statuses: any;
    brands: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    private sub: any;
    error_msg = false;
    constructor(
        private router: Router,
        private BrandcategoryService: BrandcategoryService,
        private route: ActivatedRoute,
        private CategoryService: CategoryService,
        private StatusService: StatusService,
        private BrandService: BrandService
    ) {}

    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Category Brand Mapping';
        this.global.layout.breadCrumb = 'Edit Category Brand Mapping';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.sub = this.route.params.subscribe(params => {
        this.id = +params['id']; // (+) converts string 'id' to a number
        // In a real app: dispatch action to load the details here.
    });
    this.BrandcategoryService.getbrandcategory(this.id)
    .subscribe(result => {
        if (result.stat !== false) {
            this.brandcategory = JSON.parse(result);
        }
        this.CategoryService.listActiveLastChildCategory(this.brandcategory.category_id)
        .subscribe(resultCategory => {
            this.categories = JSON.parse(resultCategory);
        });
        this.BrandService.listBrandId(this.brandcategory.brand_id)
        .subscribe(resultBrand => {
            this.brands = resultBrand.content;
        });
        return true;
    });
    this.StatusService.listStatusId()
    .subscribe(result => {
        if ( result !== false) {
            this.statuses = result.content;
        }
    });
  }

    // destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // Update brand category values.
    editBrandcategory() {
        this.loading = true;
        this.BrandcategoryService.editBrandcategory(this.brandcategory)
        .subscribe(result => {
            this.serviceCalled = true;
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/category-brand-mapping']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
    close () {
        this.serviceCalled = false;
    }

}
