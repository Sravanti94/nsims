import { Component, OnInit } from '@angular/core';
import { BrandcategoryService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Router } from '@angular/router';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
  selector: 'my-vendor',
  templateUrl: './brandCategory.component.html',
  providers: [BrandcategoryService]
})
export class BrandCategoryComponent implements OnInit {
settings = {
      mode : 'external',
      columns: {
        brand_name: {
          title: 'Brand',
          type: 'custom',
          renderComponent: CustomRenderComponent,
        },
        category_name: {
          title: 'Category',
          type: 'custom',
          renderComponent: CustomRenderComponent,
        },
        status_name: {
          title: 'Status',
          type: 'custom',
          renderComponent: CustomRenderComponent,
        }
      },
      actions: {
        columnTitle: 'Actions',
        add: false,
        edit: true,
        delete: false,
        position: 'right',
      },
       pager: {
        display: false,
        perPage: 10,
      },
      edit: {
          editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
          deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    brandcategory: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    protected brandcategoryService: BrandcategoryService) { }

     // implement OnInit's `ngOnInit` method
    ngOnInit() {
      this.global.layout.title = 'Category Brand Mapping';
      this.global.layout.breadCrumb = 'Category Brand Mapping List';
      this.global.layout.cardTilte = 'Dashboard Layout';

      this.brandcategoryService.listBrandcategory(this.global.paginator.getRows, this.global.paginator.rows,
        this.global.paginator.defaultPage)
      .subscribe(result => {
        if ( result !== false) {
          this.brandcategory = JSON.parse(result);
          this.source = new LocalDataSource(this.brandcategory);
        }
        return true;
       });
     }

  // redirect to 'category-brand-mapping' edit.
  editPreleveur(rowData) {
    this.router.navigate(['/category-brand-mapping/edit/' + rowData.data.id]);
  }

  // redirect to 'category-brand-mapping' delete.
  deletePreleveur(rowData) {
    if (window.confirm('Are you sure you want to delete?')) {
    this.brandcategoryService.deleteBrandcategory(rowData.data.id)
    .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
    } else {
        Promise.reject('cancled').then(function(error) {
            return error;
        }, function(error) {
            return error;
        });
    }
}
  // redirect to 'category-brand-mapping' add.
  clicked() {
    this.router.navigate(['/category-brand-mapping/add']);
  }
}
