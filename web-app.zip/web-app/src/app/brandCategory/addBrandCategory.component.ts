import { Component, OnInit } from '@angular/core';
import { BrandcategoryService } from '../_services/index';
import { Router } from '@angular/router';
import { CategoryService } from '../_services/index';
import { BrandService } from '../_services/index';
import { Global } from './../global';

@Component({
  selector: 'my-brandcategory',
  templateUrl: './addBrandCategory.component.html',
  providers: [BrandcategoryService , CategoryService , BrandService]
})
export class AddBrandCategoryComponent implements OnInit {
    brandcategory: any = {};
    loading = false;
    error = '';
    categories: any;
    brands: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    category_id: number = 0;
    brand_id: number = 0;
    error_msg = false;
    constructor(
      private router: Router,
      private BrandcategoryService: BrandcategoryService,
      private CategoryService: CategoryService,
      private BrandService: BrandService) { }

    // implement categories in  `ngOnInit` method
    ngOnInit() {
      this.global.layout.title = ' Category Brand Mapping';
      this.global.layout.breadCrumb = 'Add Category Brand Mapping';
      this.global.layout.cardTilte = 'Dashboard Layout';
      this.CategoryService.listActiveLastChildCategory(this.category_id)
        .subscribe(result => {
            this.categories = JSON.parse(result);
        });

        this.BrandService.listBrandId(this.brand_id)
        .subscribe(result => {
            this.brands = result.content;
        });
    }
    // add new values in brand category
    addBrandcategory() {
      this.loading = true;
      this.BrandcategoryService.addBrandcategory(this.brandcategory.brand_id, this.brandcategory.category_id, this.brandcategory.status_id)
      .subscribe(result => {
        if (result.stat === true) {
          this.msg = result.msg[0];
          this.router.navigate(['/category-brand-mapping']);
          this.loading = false;
        } else {
          this.serviceCalled = true;
          this.error_msg = true;
          this.msg = result.msg[0];
          this.error = result.stat;
          this.loading = false;
        }
      });
    }
    close() {
        this.serviceCalled = false;
    }
  }
