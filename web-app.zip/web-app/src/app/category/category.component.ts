import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
    selector: 'my-category',
    templateUrl: './category.component.html',
    providers: [CategoryService]
})
export class CategoryComponent implements OnInit {
    settings = {
        mode: 'external',
        columns: {
            category_name: {
              title: 'Name',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            status_name: {
              title: 'Status',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            }
        },
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            position: 'right',
        },
        pager: {
            display: false,
            perPage: 10,
        },
        edit: {
          editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
          deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    category: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    private CategoryService: CategoryService) { }

    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Category List';
        this.global.layout.breadCrumb = 'Category';
        this.global.layout.cardTilte = 'Dashboard Layout';

        this.CategoryService.listCategory(this.global.paginator.getRows, this.global.paginator.rows, this.global.paginator.defaultPage)
        .subscribe(result => {
            if ( result !== false) {
                this.category = JSON.parse(result);
                this.source = new LocalDataSource(this.category);
            }
            return true;
        });
    }

    // Redirecting to category edit.
    editPreleveur(rowData) {
        this.router.navigate(['/category/edit/' + rowData.data.id]);
    }

    // Delete data from 'nt_categoryservice'
     deletePreleveur(rowData) {
         if (window.confirm('Are you sure you want to delete?')) {
         this.CategoryService.deleteCategory(rowData.data.id)
         .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
    } else {
        Promise.reject('cancled').then(function(error) {
            return error;
        }, function(error) {
            return error;
        });
    }
}
    // Redireccting to category add.
    clicked() {
        this.router.navigate(['/category/add']);
    }

}
