import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CategoryService, StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-category',
    templateUrl: './editCategory.component.html',
    providers: [CategoryService, StatusService]
})
export class EditCategoryComponent implements OnInit, OnDestroy {
    category: any = {};
    loading = false;
    error = '';
    id: number;
    private sub: any;
    categories;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    statuses: any;
    error_msg = false;
    userData: any;
    retrievedData: any;
    constructor(
    private router: Router,
    private CategoryService: CategoryService,
    private StatusService: StatusService,
    private route: ActivatedRoute) {}

    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Category';
        this.global.layout.breadCrumb = 'Edit Category';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id'];
        });

        this.CategoryService.getCategory(this.id)
        .subscribe(result => {
            if ( result !== false) {
                this.category = JSON.parse(result);
            }
            this.CategoryService.listCategoryId(this.category.parent_id)
            .subscribe(resultCategories => {
                    this.categories = resultCategories.content;
            });
            return true;
        });
         this.StatusService.listStatusId()
         .subscribe(result => {
             if ( result !== false) {
                 this.statuses = result.content;
            }
        });
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }
    }

    // destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // update category status.
    editCategory() {
        this.loading = true;
        this.CategoryService.editCategory(this.category, this.userData)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/category']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
  }
  close () {
        this.serviceCalled = false;
    }
}
