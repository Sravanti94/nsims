import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CategoryService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-logistics',
    templateUrl: './addCategory.component.html',
    providers: [CategoryService]
})
export class AddCategoryComponent implements OnInit {

    category: any = {};
    loading = false;
    error = '';
    categories: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    category_id: number = 0;
    error_msg = false;
    userData: any;
    retrievedData: any;
    constructor(
    private router: Router,
    private CategoryService: CategoryService) {}

    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Category';
        this.global.layout.breadCrumb = 'Add Category';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.CategoryService.listCategoryId(this.category_id)
        .subscribe(result => {
            this.categories = result.content;
        });
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }
    }

    // Add new category Values
    addCategory() {
        this.loading = true;
        this.CategoryService.addCategory(this.category, this.userData)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/category']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
    close() {
        this.serviceCalled = false;
    }
}
