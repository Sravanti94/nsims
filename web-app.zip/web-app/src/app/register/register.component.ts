import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserService } from '../_services/index';
import { NgForm } from '@angular/forms';
import { Global } from './../global';

@Component({
    selector: 'my-register',
    templateUrl: './register.component.html',
    providers: [AuthenticationService, UserService],
})
export class RegisterComponent implements OnInit {

    model: any = {};
    loading = false;
    error = '';
    serviceCalled: boolean = false;
    msg: string = '';
    global: any = Global;
    ErrMsg: string = '';
    constructor(
    private router: Router,
    private userService: UserService) {}
    // the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {

    }
    // Add new user Details in 'nt_user'
    register(r: NgForm) {
        this.loading = true;
        this.userService.register(this.model)
        .subscribe(result => {
            this.serviceCalled = true;
            if (result.stat === true) {
                // set success message and pass true paramater to persist the message after redirecting to the login page
                // this.alertService.success('Registration successful', true);
                this.msg = result.msg[0];
                this.error = result.stat;
                this.router.navigate(['/register']);
                this.loading = false;
                r.resetForm();
            } else {
                this.ErrMsg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
}
