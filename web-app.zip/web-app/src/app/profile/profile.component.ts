import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService, UserService } from '../_services/index';
// import { NgForm } from '@angular/forms';
import { Global } from './../global';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector: 'my-profile',
    templateUrl: './profile.component.html',
    providers: [AuthenticationService, UserService],
})
export class ProfileComponent implements OnInit {

    model: any = {};
    retrievedData: any;
    userData: any;
    loading = false;
    error = '';
    serviceCalled: boolean = false;
    msg: string = '';
    global: any = Global;
    private sub: any;
    id: number;
    success_msg = false;
    errMsg = false;
    constructor(
    private router: Router,
    private route: ActivatedRoute,
    private userService: UserService) {}
    // the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Update Profile';
        this.global.layout.breadCrumb = 'Update Profile';
        this.global.layout.cardTilte = 'Update Profile';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }
        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number

        // In a real app: dispatch action to load the details here.
        });

        this.userService.getUserById(this.userData.user_id)
        .subscribe(result => {
            if ( result.stat !== false) {
                this.model = result.content;
            }
            return true;
        });
    }
    // Add new user Details in 'nt_user'
    profile() {
        this.loading = true;
        this.userService.profile(this.model)
        .subscribe(result => {
            this.serviceCalled = true;
            if (result.stat === true) {
                let retrievedData = localStorage.getItem('currentUser');
                if (retrievedData) {
                    let userdata = JSON.parse(retrievedData);
                    if (parseInt(userdata.user_role_id, 0) === Global.role.superAdmin) {
                        // navigate to superadmin dashboard
                        this.errMsg = false;
                        this.success_msg = true;
                        this.msg = result.msg[0];
                        this.error = result.stat;
                        this.resetfield();
                        this.router.navigate(['profile']);
                        this.loading = false;
                    } else if (parseInt(userdata.user_role_id, 0) === Global.role.primary) {
                        // navigate to primary dashboard
                        this.success_msg = true;
                        this.errMsg = false;
                        this.msg = result.msg[0];
                        this.error = result.stat;
                        this.resetfield();
                        this.router.navigate(['/profile/p']);
                        this.loading = false;
                        return false;
                    } else if (parseInt(userdata.user_role_id, 0) === Global.role.secondary) {
                        // navigate to secondary dashboard
                        this.success_msg = true;
                        this.errMsg = false;
                        this.msg = result.msg[0];
                        this.error = result.stat;
                        this.resetfield();
                        this.router.navigate(['/profile/sa']);
                        this.loading = false;
                        return false;
                    }
                }
              //  p.resetForm();
            } else {
                this.success_msg = false;
                this.serviceCalled = true;
                this.errMsg = true;
                this.errMsg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
    resetfield() {
        this.model.password = '';
        this.model.confirmPassword = '';
    }
    close () {
        this.serviceCalled = false;
    }
}
