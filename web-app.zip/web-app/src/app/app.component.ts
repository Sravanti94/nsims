import { Component } from '@angular/core';
import { ApiService } from './shared';
import '../assets/styles/app.scss';

@Component({
  selector: 'my-app', // <my-app></my-app>
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [ApiService],
})

export class AppComponent {
  url = 'https://github.com/preboot/angular2-webpack';
  title: string;
  clicked: string = null;

  constructor(private api: ApiService) {
    this.title = this.api.title;
  }

  navigationClick(clicked: string): void {
    this.clicked = this.clicked === clicked ? null : clicked;
  }
}
