import { Component, OnInit } from '@angular/core';
import { Global } from './../global';
@Component({
  selector: 'my-about',
  templateUrl: './superaccount.component.html',
  // styleUrls: ['./about.component.scss']
})
export class SuperAccountComponent implements OnInit {
  // @maheshPerla: the below link used to trigger the inline edit save  to call the api
  // https://github.com/akveo/ng2-smart-table/issues/284
  global: any = Global;
  constructor() {
        // Do stuff
  }
  // the list adding them to the current object in 'ngoninit' method.
  ngOnInit() {
    this.global.layout.title = 'Welcome to Dashboard';
    this.global.layout.breadCrumb = 'Dashboard';
    this.global.layout.cardTilte = 'Dashboard';
  }

}
