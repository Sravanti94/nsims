import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { routing } from './app.routing';
import { HttpModule } from '@angular/http';
import { AuthGuard, PrimaryAccountAuthGuard } from './_guards/index';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { ApiService } from './shared';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import 'hammerjs';

import { AppComponent } from './app.component';

import { DefaultLayoutComponent } from './defaultLayout/defaultLayout.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { FeaturesComponent } from './extraPages/features.component';
import { PricingComponent } from './extraPages/pricing.component';
import { ContactUsComponent } from './extraPages/contactUs.component';
import { SupportComponent } from './extraPages/support.component';
import { PartnerWithUsComponent } from './extraPages/partnerWithUs.component';
import { TermsAndServiceComponent } from './extraPages/termsAndService.component';
import { AccountingComponent } from './extraPages/accounting.component';
import { PrivacyPolicyComponent } from './extraPages/privacyPolicy.component';
import { ProductAndListingComponent } from './extraPages/productAndListing.component';
import { InventoryManagementComponent } from './extraPages/inventoryManagement.component';
import { OrderFullfillmentComponent } from './extraPages/orderFullfillment.component';
import { ReportingComponent } from './extraPages/reporting.component';
import { AboutComponent } from './about/about.component';

import { DashboardLayoutComponent } from './dashboardLayout/dashboardLayout.component';
import { SuperAccountComponent } from './sa/superaccount.component';

import { AddCategoryComponent } from './category/addCategory.component';
import { CategoryComponent } from './category/category.component';
import { EditCategoryComponent } from './category/editCategory.component';
import { AddBrandComponent } from './brand/addBrand.component';
import { BrandComponent } from './brand/brand.component';
import { EditBrandComponent } from './brand/editBrand.component';
import { AddSizeTypeComponent } from './sizeType/addSizeType.component';
import { SizeTypeComponent } from './sizeType/sizeType.component';
import { EditSizeTypeComponent } from './sizeType/editSizeType.component';
import { AddSizeTypeCategoryComponent } from './sizeTypeCategory/addSizeTypeCategory.component';
import { SizeTypeCategoryComponent } from './sizeTypeCategory/sizeTypeCategory.component';
import { EditSizeTypeCategoryComponent } from './sizeTypeCategory/editSizeTypeCategory.component';
import { AddProductComponent } from './product/addProduct.component';
import { ProductComponent } from './product/product.component';
import { EditProductComponent } from './product/editProduct.component';
import { AddBrandCategoryComponent } from './brandCategory/addBrandCategory.component';
import { BrandCategoryComponent } from './brandCategory/brandCategory.component';
import { EditBrandCategoryComponent } from './brandCategory/editBrandCategory.component';
import { ProfileComponent } from './profile/profile.component';
import { UsersComponent } from './users/users.component';
import { UserProfileComponent } from './users/userProfile.component';
import { CustomRenderComponent } from './render/render.component';

import { PrimaryAccountComponent } from './pa/primaryaccount.component';
import { AddVendorComponent } from './vendor/addVendor.component';
import { EditVendorComponent } from './vendor/editVendor.component';
import { VendorComponent } from './vendor/vendor.component';
import { AddSellerProductComponent } from './sellerProduct/addSellerProduct.component';
import { SellerProductComponent } from './sellerProduct/sellerProduct.component';
import { EditSellerProductComponent } from './sellerProduct/editSellerProduct.component';
import { AddLogisticsComponent } from './logistics/addLogistics.component';
import { LogisticsComponent } from './logistics/logistics.component';
import { EditLogisticsComponent } from './logistics/editLogistics.component';
import { AddWarehouseComponent } from './warehouse/addWarehouse.component';
import { WarehouseComponent } from './warehouse/warehouse.component';
import { EditWarehouseComponent } from './warehouse/editWarehouse.component';

import {  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
  MatCommonModule
} from '@angular/material';



@NgModule({
  declarations: [
    AppComponent,
    DefaultLayoutComponent,
    LoginComponent,
    LogoutComponent,
    RegisterComponent,
    FeaturesComponent,
    PricingComponent,
    ContactUsComponent,
    SupportComponent,
    PartnerWithUsComponent,
    TermsAndServiceComponent,
    AccountingComponent,
    PrivacyPolicyComponent,
    ProductAndListingComponent,
    InventoryManagementComponent,
    OrderFullfillmentComponent,
    ReportingComponent,
    AboutComponent,
    DashboardLayoutComponent,
    AddCategoryComponent,
    CategoryComponent,
    EditCategoryComponent,
    SuperAccountComponent,
    AddBrandComponent,
    BrandComponent,
    EditBrandComponent,
    AddSizeTypeComponent,
    SizeTypeComponent,
    EditSizeTypeComponent,
    AddSizeTypeCategoryComponent,
    SizeTypeCategoryComponent,
    EditSizeTypeCategoryComponent,
    AddProductComponent,
    ProductComponent,
    EditProductComponent,
    AddBrandCategoryComponent,
    BrandCategoryComponent,
    EditBrandCategoryComponent,
    ProfileComponent,
    UsersComponent,
    UserProfileComponent,
    CustomRenderComponent,
    PrimaryAccountComponent,
    EditVendorComponent,
    AddVendorComponent,
    VendorComponent,
    AddSellerProductComponent,
    SellerProductComponent,
    EditSellerProductComponent,
    AddLogisticsComponent,
    LogisticsComponent,
    EditLogisticsComponent,
    AddWarehouseComponent,
    WarehouseComponent,
    EditWarehouseComponent,
  ],
  imports: [
    BrowserModule,
    routing,
    FormsModule,
    HttpModule,
    Ng2SmartTableModule,
    BrowserAnimationsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
    MatCommonModule
  ],
  providers: [
    ApiService,
    AuthGuard,
    PrimaryAccountAuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
