import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
    selector: 'my-product',
    templateUrl: './product.component.html',
    providers: [ProductService],
})
export class ProductComponent implements OnInit {
    settings = {
        mode: 'external',
        columns: {
           product_name: {
              title: 'Name',
              width: '260px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            product_code: {
              title: 'Product Code',
              width: '150px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            product_sku: {
              title: 'SKU',
              width: '450px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            category_name: {
              title: 'Category',
              width: '200px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            brand_name: {
              title: 'Brand',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            color: {
              title: 'Color',
              width: '100px',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            size_type_name: {
              title: 'Size Type',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            size: {
              title: 'Size',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            hsn: {
              title: 'HSN',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            status_name: {
              title: 'Status',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            }
        },
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            position: 'right',
        },
        pager: {
            display: false,
        },
        edit: {
          editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
          deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    product: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    private ProductService: ProductService) { }

    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Master Products List';
        this.global.layout.breadCrumb = 'Master Products';
        this.global.layout.cardTilte = 'Dashboard Layout';

        this.ProductService.listProduct(this.global.paginator.getRows, this.global.paginator.rows, this.global.paginator.defaultPage)
        .subscribe(result => {

            if ( result !== false) {
                this.product = JSON.parse(result);
                this.source = new LocalDataSource(this.product);
            }
            return true;
        });
    }
    // Redirecting to edit product.
    editPreleveur(rowData) {
        this.router.navigate(['/product/edit/' + rowData.data.id]);
    }
    // Deleting data from 'nt_products'
    deletePreleveur(rowData) {
        this.ProductService.deleteProduct(rowData.data.id)
        .subscribe(result => {
            if ( result !== false) {
                return true;

            }
            return false;
        });
    }
    // Redirecting to add product.
    clicked() {
        this.router.navigate(['/product/add']);
    }
    // Redirecting to add bulk product.
    click() {
        this.router.navigate(['/product/bulk-upload']);
    }

}
