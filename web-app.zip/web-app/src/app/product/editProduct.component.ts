import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { ProductService } from '../_services/index';
import { CategoryService } from '../_services/index';
import { BrandService } from '../_services/index';
import { SizeTypeService } from '../_services/index';
import { StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-product',
    templateUrl: './editProduct.component.html',
    providers: [ProductService , CategoryService , BrandService , SizeTypeService , StatusService]
})
export class EditProductComponent implements OnInit, OnDestroy {
    product: any = {};
    loading = false;
    error = '';
    id: number;
    retrievedData: any;
    userData: any;
    private sub: any;
    categories: any;
    brands: any;
    sizetypes: any;
    statuses: any;
    global: any = Global;
    bname: any;
    serviceCalled: boolean = true;
    msg: string = '';
    error_msg = false;
    constructor(
    private router: Router,
    private ProductService: ProductService,
    private route: ActivatedRoute,
    private CategoryService: CategoryService,
    private SizeTypeService: SizeTypeService,
    private BrandService: BrandService,
    private StatusService: StatusService) {}

    // Iterates through the list of champions adding them to the current object in 'ngonInit' method.
    ngOnInit() {
        this.global.layout.title = 'Master Products';
        this.global.layout.breadCrumb = 'Edit Master Products';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });

        this.ProductService.getProduct(this.id)
        .subscribe(result => {
            if ( result !== false) {
                this.product = JSON.parse(result);
                if (this.product.hsn === 0) {
                    this.product.hsn = '';
                }
                this.BrandService.listBrandByCategory(this.product.category_id, this.product.brand_id)
                .subscribe(resultBrand => {
                    this.brands = resultBrand.content; // " [{'id':'1','name':'ss'}] ";
                });
                this.SizeTypeService.listSizeTypeByCategory(this.product.category_id, this.product.size_type_id)
                .subscribe(resultSizeType => {
                    this.sizetypes = resultSizeType.content;
                });
                this.CategoryService.listActiveLastChildCategory(this.product.category_id)
                .subscribe(resultCategory => {
                    this.categories = JSON.parse(resultCategory);
                });
            }
            return true;
        });

        this.StatusService.listStatusId()
        .subscribe(result => {
            this.statuses = result.content;
        });
    }

    // destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // edit product details in 'nt_product'
    editProduct() {
        this.loading = true;
        this.ProductService.editProduct(this.product, this.userData)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/product']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;

            }
        });
    }
    // To show the brands and sizetype according to the selected category
    onSelect(categoryid) {
      this.BrandService.listBrandByCategory(categoryid, this.product.brand_id)
      .subscribe(result => {
          this.brands = result.content; // " [{'id':'1','name':'ss'}] ";
        });
        this.SizeTypeService.listSizeTypeByCategory(categoryid, this.product.size_type_id)
        .subscribe(result => {
            this.sizetypes = result.content;
        });
    }
    // To auto generate the product sku
    createProductSku(brand_id, name, color, size_type_id, size) {
            this.SizeTypeService.getSizeType(size_type_id)
            .subscribe(resultSizeType => {
                let result = JSON.parse(resultSizeType);
                let size_type = result.name;
                this.BrandService.getBrand(brand_id)
                .subscribe(resultBrand => {
                    let res = JSON.parse(resultBrand);
                    let bname = res.name;
                    let sku: any = '';
                    let re = / /gi;

                    let first_hit = false;

                    if (name) {
                        name = name.trim();
                        name = name.replace(re, '-');
                        first_hit = true;
                        sku = name;
                    }

                    if (bname && first_hit) {
                        bname = bname.trim();
                        bname = bname.replace(re, '-');
                       sku += '-' + bname;
                    } else if (bname && !first_hit) {
                        first_hit = true;
                        bname = bname.trim();
                        bname = bname.replace(re, '-');
                        sku = bname;
                    }

                    if (color  && first_hit) {
                        color = color.trim();
                        color = color.replace(re, '-');
                        sku += '-' + color;
                    } else if (color && !first_hit) {
                        first_hit = true;
                        color = color.trim();
                        color = color.replace(re, '-');
                        sku = color;
                    }

                    if (size_type  && first_hit) {
                        size_type = size_type.trim();
                        size_type = size_type.replace(re, '-');
                        sku += '-' + size_type;
                    } else if (size_type && !first_hit) {
                        first_hit = true;
                        size_type = size_type.trim();
                        size_type = size_type.replace(re, '-');
                        sku = size_type;
                    }

                    if (size  && first_hit) {
                        sku += '-' + size;
                    } else if (size && !first_hit) {
                        first_hit = true;
                        sku = size;
                    }

                    sku = sku.toUpperCase( );
                    this.product.product_sku = sku;
                });
            });
    }
    close () {
        this.serviceCalled = false;
    }
}
