import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class ProductService {

    constructor(private http: Http) {
    }

    // Add new product details in 'nt_product'.
    addProduct(product: any, userdata: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    name: product.name,
                    category_id: product.category_id,
                    product_code: product.product_code,
                    product_sku: product.product_sku,
                    brand_id: product.brand_id,
                    color: product.color,
                    size_type_id: product.size_type_id,
                    size: product.size,
                    created_by: userdata.user_id,
                    hsn: product.hsn,
                    quantity: product.quantity });
        return this.http.post(`${apiUrl}/product/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();

            });
    }

    // Edit product details in 'nt_product'.
    editProduct(product: any, userdata) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    id: product.id,
                    name: product.name,
                    category_id: product.category_id,
                    product_code: product.product_code,
                    product_sku: product.product_sku,
                    brand_id: product.brand_id,
                    color: product.color,
                    size_type_id: product.size_type_id,
                    size: product.size,
                    status_id: product.status_id,
                    created_by: userdata.user_id,
                    hsn: product.hsn,
                    quantity: product.quantity });
        return this.http.post(`${apiUrl}/product/edit`, data , {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get the purticular id details from'nt_product'.
    getProduct(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/product/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // Get active details form 'nt_product'.
    listProduct(count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/product/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // List category by ID.
    brandListByCategory() {

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/brand-category`)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res.content;
                }else {
                    return res.stat;
                }
            });
    }

    // List products by id.
    listActiveProduct(product_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/product/active/` + product_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }

    // Change 'status in 'nt_status=5'delete.
    deleteProduct(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/product/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // Add the products through excel.
    addProductExcel(dat: any , category: number, brand: string, userdata: number) {
        dat = {dat, category, brand, userdata};
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify(dat);
        return this.http.post(`${apiUrl}/product/add/excel`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // check the products details.
    checkProductExcel(dat: any, brand: number, category: number) {
        let dat_obj = {dat: dat, brand: brand, category: category};
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify(dat_obj);
        return this.http.post(`${apiUrl}/product/check/excel`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // List products by id.
    listActiveProductByBrand(brand_id: number, seller_id: number, category_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/product/by/brand/` + brand_id + '/' + seller_id + '/' + category_id)
            .map((response: Response) => {
                let res = response.json();
                    return res;
            });
    }

	// create the excel sheet
    createExcel(category_id: number , brand_id: number) {
        return this.http.get(`${apiUrl}/create/excel/` + category_id + '/' + brand_id)
        .map((response: Response) => {
            return response;
        });
    }
    // create the excel sheet
    createErrorExcel(category_id: number, brand_id: number, dat: any) {

        dat = {category_id, brand_id, dat};
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify(dat);
        return this.http.post(`${apiUrl}/create/product/error/excel`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

}
