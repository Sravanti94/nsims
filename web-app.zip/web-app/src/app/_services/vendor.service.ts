import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { apiUrl } from './../global';

@Injectable()
export class VendorService {
    public token: string;

    constructor(private http: Http) {
        // set token if saved in local storage
        let currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.token = currentUser && currentUser.token;
    }

    // Add new vendors in 'nt_Vendors'.
    addVendor(vendor: any, userData: any) {
      vendor = Object.assign({ }, userData, vendor);
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let data = JSON.stringify(vendor);
        return this.http.post(`${apiUrl}/vendors/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Edit vendor details in 'nt_Vendors'.
    editVendorApi(vendor: any, userData: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    id: vendor.id,
                    name: vendor.name,
                    nick_name: vendor.nick_name,
                    address: vendor.address,
                    city: vendor.city,
                    email: vendor.email,
                    phone: vendor.phone,
                    status_id: vendor.status_id,
                    created_by: userData.user_id});
        return this.http.post(`${apiUrl}/vendors/edit`, data, {headers : headers})
            .map((response: Response) => {
              return response.json();

            });
    }

    // get the purticular id details from'nt_Vendors'.
     getVendor(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/vendors/get/`  + id)
            .map((response: Response) => {
              let res = response.json();
                if ( res.stat === true ) {
                  return JSON.stringify(res.content);
                }else {
                  return res.stat;
                }
              });
    }

    // List details form 'nt_Vendors'.
    listVendor(id: number, count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/vendors/` + id + '/' + count + '/' + limit + '/' + page)
            .map((response: Response) => {
              let res = response.json();
                if ( res.stat === true ) {
                  return JSON.stringify(res.content);
                }else {
                  return res.stat;
                }
              });
    }

    // Change 'status in 'nt_status=5'delete.
    deleteVendor(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/vendors/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // List details form 'nt_Vendors'.
    listActiveVendor(id: number, vendor_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/vendors/active/` + id + `/` + vendor_id)
            .map((response: Response) => {
                return response.json();
            });
    }

}
