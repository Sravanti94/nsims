import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class BrandcategoryService {

    constructor(private http: Http) {
    }

   // Add new brand category details in 'Brand_category'.
    addBrandcategory(brand_id: string, category_id: string, status_id: string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({ brand_id: brand_id, category_id: category_id, status_id: status_id });
        return this.http.post(`${apiUrl}/category-brand-mapping/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();

            });
    }

    // Edit brand category details in 'Brand_category'
    editBrandcategory(brandcategory: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({id: brandcategory.id, brand_id: brandcategory.brand_id,
         category_id: brandcategory.category_id, status_id: brandcategory.status_id });
        return this.http.post(`${apiUrl}/category-brand-mapping/edit`, data , {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get id details from 'nt_brand_category'
    getbrandcategory(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-brand-mapping/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // List Active status=1 details from 'nt_brand_category'
    listBrandcategory(count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-brand-mapping/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();
                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
        }
    // Delete 'status in 'nt_status=5'delete.
    deleteBrandcategory(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-brand-mapping/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
}
