import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class SizeTypeService {

    constructor(private http: Http) {
    }

    // Add new size type details in 'nt_siz_type'.
    addSizeType(sizetype: any, userData: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    name: sizetype.name,
                    created_by: userData.user_id
                    });
        return this.http.post(`${apiUrl}/size-type/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();

            });
    }

    // Edit size type details in 'nt_siz_type'.
    editSizeType(sizetype: any, userData: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    id: sizetype.id,
                    name: sizetype.name,
                    status_id: sizetype.status_id,
                    created_by: userData.user_id
                    });
        return this.http.post(`${apiUrl}/size-type/edit`, data , {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get the purticular id details from'nt_siz_type'.
    getSizeType(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/size-type/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }
    // Get active details form 'nt_siz_type'.
    listSizeType(count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/size-type/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

     // List category by ID.
    activeSizeTypelist(size_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/size-type/id/` + size_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }
    // Change 'status in 'nt_status=5'delete.
    deleteSizetype(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/size-type/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

 listSizeTypeByCategory(categoryid: number, size_type_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-sizetype-mapping/getsize_type/`  + categoryid + '/' + size_type_id)
            .map((response: Response) => {
                let res = response.json();
                return res;
            });

    }

}
