import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class SizeTypeCategoryService {

    constructor(private http: Http) {
    }

   // Add new size type category  details in 'size_ typecategory'.
    addSizeTypeCategory(size_id: string, category_id: string, status_id: string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({ size_id: size_id, category_id: category_id, status_id: status_id });
        return this.http.post(`${apiUrl}/category-sizetype-mapping/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();

            });
    }

    // Edit size type category details in 'size_ typecategory'
    editSizeTypeCategory(sizetypecategory: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({id: sizetypecategory.id, size_id: sizetypecategory.size_id,
         category_id: sizetypecategory.category_id, status_id: sizetypecategory.status_id });
        return this.http.post(`${apiUrl}/category-sizetype-mapping/edit`, data , {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get id details from 'nt_size_ typecategory'
    getSizeTypeCategory(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-sizetype-mapping/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // List Active status=1 details from 'nt_size_ typecategory'
    listSizeTypeCategory(count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-sizetype-mapping/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();
                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
        }

    // Delete 'status in 'nt_status=5'delete.
    deleteSizeTypeCategory(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-sizetype-mapping/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
}
