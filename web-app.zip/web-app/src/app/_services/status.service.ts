import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class StatusService {

    constructor(private http: Http) { }
	// list status id.
    listStatusId() {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/status/id`)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }
	// List user status using by id.
    listUserStatusId() {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/user-status/id`)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }
}
