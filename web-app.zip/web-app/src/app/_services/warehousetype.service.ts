import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class WarehouseTypeService {

    constructor(private http: Http) { }

    // List warehouse typebyid'nt_warehouse_types.
    listWarehouseTypeId() {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/warehouse-type/id`)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }
    
    // List warehouse typebyid'nt_warehouse_types.
    listWarehouseActive() {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/warehouses-active/id`)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }
}
