import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { apiUrl } from './../global';

@Injectable()
export class CategoryService {

    constructor(private http: Http) {
    }

    // Add new category details in 'nt_category'.
    addCategory(category: any, userData: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({name: category.name, level: category.level, parent_id: category.parent_id,
         status_id: category.status_id, created_by: userData.user_id});

        return this.http.post(`${apiUrl}/category/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Edit category details in 'nt_category'.
    editCategory(category: any, userData: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({id: category.id, name: category.name, level: category.level,
         parent_id: category.parent_id,  status_id: category.status_id, created_by: userData.user_id });

        return this.http.post(`${apiUrl}/category/edit`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get the purticular id details from'nt_category'.
    getCategory(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/category/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // Get active details form 'nt_category'.
    listCategory(count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/category/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // List 'nt_category' by ID.
    listCategoryId(category_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/category/id/` + category_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }

    // Change 'status in 'nt_status=5'delete.
    deleteCategory(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // list categories by parent_id
    listCategoryByParentId(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category/parent/id/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }

    // list categories which has no parent
    listCategoryParent() {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category/parent`)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }

    // check the brand is exist for the perticular category
    checkBrand(brand: string, category: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category/brand/` + category + '/' + brand )
            .map((response: Response) => {
                let res = response.json();
                    return res;
            });
    }

    // Get last child details form 'nt_category'.
    listActiveLastChildCategory(category_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/category/last/active/child/` + category_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // Get last child details form 'nt_category'.
    listRestChildCategory(size_type_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/category/rest/active/child/` + size_type_id)
            .map((response: Response) => {
                return response.json();
            });
    }
}
