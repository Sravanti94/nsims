import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class BrandService {

    constructor(private http: Http) {
    }

    // Add new brand details in 'nt_brand'.
    addBrand(brand: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({ name: brand.name });
        return this.http.post(`${apiUrl}/brand/add`, data, {headers : headers})
        .map((response: Response) => {
            return response.json();
            });
    }

    // Edit brand details in 'nt_brand'.
    editBrand(brand: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({id: brand.id, name: brand.name, status_id: brand.status_id });
        return this.http.post(`${apiUrl}/brand/edit`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get the purticular id details from'nt_brand'.
    getBrand(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/brand/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // Get active details form 'nt_brand'.
    listBrand(count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/brand/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                  return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // List active details form 'nt_brand'.
    listBrandId(brand_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/brand/active/` + brand_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }

    // Change 'status in 'nt_status=5'delete.
    deleteBrand(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/brand/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
    listBrandByCategory(categoryid: number, brandid: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/category-brand-mapping/getbrands/`  + categoryid + '/' + brandid)
            .map((response: Response) => {
                let res = response.json();
                return res;
            });

    }
}
