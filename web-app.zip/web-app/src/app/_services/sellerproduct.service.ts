import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class SellerProductService {

    constructor(private http: Http) {
    }
    // Add new product details in 'nt_seller_product'.
    addSellerProduct(sellerproduct: any, userdata: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    product_id: sellerproduct.product_id,
                    created_by: userdata.user_id,
                    seller_id: userdata.user_id });
        return this.http.post(`${apiUrl}/your-products/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();

            });
    }
    // Update product details in 'nt_seller_product'.
    editSellerProduct(sellerproduct: any, userdata) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    id: sellerproduct.id,
                    product_id: sellerproduct.product_id,
                    created_by: userdata.user_id,
                    seller_id: userdata.user_id,
                    status_id: sellerproduct.status_id });

        return this.http.post(`${apiUrl}/your-products/edit`, data , {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }
    // Get the purticular id details from'nt_seller_product'.
    getSellerProduct(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/your-products/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }
   // Get  details form 'nt_seller_product'.
    listSellerProduct(id: number, count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/your-products/` + id + '/' + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
    // Get active seller product details form 'nt_seller_product'.
    stockInSellerProduct(id: number, product_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/stock-in-seller-product/` + id + `/` + product_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
     // Get active seller product details form 'nt_seller_product'.
    stockInNSSellerProduct(id: number, product_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/stock-in-ns-seller-product/` + id + `/` + product_id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
    // Change 'status in 'nt_status=5'delete.
    deletesellerproduct(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/your-products/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
    // Get active seller product details form 'nt_seller_product' by brand and category.
    stockInSellerProductByBrandCategory(id: number, brand_id: number, category_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/stock-in-seller-product/brand/category/` + id + `/` + brand_id + '/' + category_id)
            .map((response: Response) => {
                let res = response.json();
                    return res;
            });
    }
    // Get active seller product details form 'nt_seller_product' by brand and category.
    stockInNSSellerProductByBrandCategory(id: number, brand_id: number, category_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');

        return this.http.get(`${apiUrl}/stock-in-seller-product/brand/category/` + id + `/` + brand_id + '/' + category_id)
            .map((response: Response) => {
                let res = response.json();
                    return res;
            });
    }

}
