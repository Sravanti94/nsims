import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import { apiUrl } from './../global';

@Injectable()
export class WarehouseService {

    constructor(private http: Http) {
    }

     // Add new warehouse details in 'nt_warehouse'.
    addWarehouse(name: string, city: string, address1: string, address2: string,
        pincode: string, email: string, phone: string, warehouse_type_id: string, created_by: string,
        status_id: string, warehouse_master_id: string) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({name: name, address1: address1, address2: address2, city: city,
            pincode: pincode, email: email, phone: phone, warehouse_type_id: warehouse_type_id,
             created_by: created_by, status_id: status_id, warehouse_master_id: warehouse_master_id });
        return this.http.post(`${apiUrl}/warehouses/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Edit warehouse details in 'nt_warehouse'.
    editWarehouse(warehouse: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({id: warehouse.id, name: warehouse.name, address1: warehouse.address1,
            address2: warehouse.address2, city: warehouse.city, pincode: warehouse.pincode, email: warehouse.email,
            phone: warehouse.phone, warehouse_type_id: warehouse.warehouse_type_id,
            created_by: warehouse.created_by, status_id: warehouse.status_id, warehouse_master_id: warehouse.warehouse_master_id });
        return this.http.post(`${apiUrl}/warehouses/edit`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get the purticular id details from'nt_warehouse'.
    getWarehouses(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/warehouses/get/`  + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // Get active details form 'nt_warehouse'.
    listWarehouse(id: number, count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/warehouses/` + id + '/' + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
/*    // Get active details form 'nt_warehouse'.
    listWarehouseSearch( queryString: any, id: number, count?: number, limit?: number, page?: number ) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/warehouses/` + id + '/' + count + '/' + limit + '/' + page+ '/' + queryString)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }*/
    // Change 'status in 'nt_status=5'delete.
    deleteWarehouse(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/warehouses/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
    // List warehouse Details By id.
    listWarehouseById(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/fullfillment-warehouses/` + id)
            .map((response: Response) => {
                let res = response.json();
                if ( res.stat === true ) {
                    return res;
                }else {
                    return res.stat;
                }
            });
    }
    // to fetch stock count report.
    stockCountReport(id: number, date: any) {
        let dat = {id, date};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/secondary-stock-count-report`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }
    // to fetch stock value report.
    stockValueReport(id: number, date: any) {
        let dat = {id, date};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/secondary-stock-value-report`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }

    // to fetch stock count report.
    primaryStockCountReport(id: number, date: any) {
        let dat = {id, date};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/primary-stock-count-report`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }
    // to fetch stock value report.
    primaryStockValueReport(id: number, date: any) {
        let dat = {id, date};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/primary-stock-value-report`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }
    // to fetch ProfitLossReportPerMonth.
    primaryProfitLossReportPerMonth(id: number, date: any) {
        let dat = {id, date};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/primary-profit-loss-report-per-month`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }
    // to fetch ProfitLossReportPerMonth.
    primarySecondarySalesReportPerMonth(id: number, date: any) {
        let dat = {id, date};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/primary-secondary-sales-report-per-month`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }

    // to fetch stock in  count report.
    primarystockInNSCount(id: number) {
        let dat = {id};
        let data = JSON.stringify(dat);
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.post(`${apiUrl}/primary-stock-in-ns-count-report`, data, {headers : headers})
            .map((response: Response) => {
                let res = response.json();
                return res;
            });
    }

}
