import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';
import { apiUrl } from './../global';

@Injectable()
export class LogisticsService {

    constructor(private http: Http) {
    }

    // Add new details in 'nt_logistics'.
    addLogistics(name: string, city: string, created_by: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    name: name,
                    city: city,
                    created_by: created_by});
        return this.http.post(`${apiUrl}/logistics/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();

            });
    }

    // Edit logistics details in 'nt_logistics'.
    editLogistics(logistics: any, userData: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify({
                    id: logistics.id,
                    name: logistics.name,
                    city: logistics.city,
                    status_id: logistics.status_id,
                    created_by: userData.user_id });
        return this.http.post(`${apiUrl}/logistics/edit`, data , {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }

    // Get the purticular id details from'nt_logistics'.
    getLogistics(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/logistics/get/` + id)
            .map((response: Response) => {
                let res = response.json();
                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }

            });
    }

    // Get active details form 'nt_logistics'.
    listLogistics(id: number, count?: number, limit?: number, page?: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/logistics/` + id + '/' + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }

    // Change 'status in 'nt_status=5'delete.
    deleteLogistics(id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/logistics/delete/` + id)
            .map((response: Response) => {
                let res = response.json();

                if ( res.stat === true ) {
                    return JSON.stringify(res.content);
                }else {
                    return res.stat;
                }
            });
    }
    // Get active details form 'nt_logistics'.
    listActiveLogistics(id: number, logistics_id: number) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        return this.http.get(`${apiUrl}/logistics/active/` + id + '/' + logistics_id)
            .map((response: Response) => {
                return response.json();
            });
    }
}
