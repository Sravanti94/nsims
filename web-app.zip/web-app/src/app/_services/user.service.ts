import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import { apiUrl } from './../global';
import { AuthenticationService } from './index';
import { User } from '../_models/index';

@Injectable()
export class UserService {
    constructor(
        private http: Http,
        private authenticationService: AuthenticationService) {
    }
    // Get user details from 'nt_users'
    getUsers(): Observable<User[]> {
        // add authorization header with jwt token
        let headers = new Headers({ 'Authorization': 'Bearer ' + this.authenticationService.token });
        let options = new RequestOptions({ headers: headers });

        // get users from api
        return this.http.get(`${apiUrl}/users`, options)
            .map((response: Response) => response.json());
    }

    // Add register details in 'nt_user'.
    register(model: any) {
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let data = JSON.stringify(model);
      return this.http.post(`${apiUrl}/user/add`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
        }
    // changing profile details
    profile(model: any) {
        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let data = JSON.stringify(model);
        return this.http.post(`${apiUrl}/user/edit`, data, {headers : headers})
            .map((response: Response) => {
                return response.json();
            });
    }
	  // all user details in 'nt_user'.
    listPrimaryUser(count?: number, limit?: number, page?: number) {
        return this.http.get(`${apiUrl}/primary/user/` + count + '/' + limit + '/' + page)
            .map((response: Response) => {
                return response.json();
            });
    }
    // get user details by id from 'nt_user'.
    getUserById(id: number) {
        return this.http.get(`${apiUrl}/user/get/` + id)
            .map((response: Response) => {
                return response.json();
            });
    }
	  // delete user details by id from 'nt_user'.
    deleteUser(id: number) {
        return this.http.get(`${apiUrl}/user/delete/` + id)
            .map((response: Response) => {
                return response.json();
            });
    }
    // forget password details.
    forgotpassword(model: any) {
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let data = JSON.stringify(model);
      return this.http.post(`${apiUrl}/forgot-password`, data, {headers : headers})
      .map((response: Response) => {
          return response.json();
        });
    }
    // reset password based on id.
    resetPassword(model: any, id: number) {
      model = Object.assign({ }, model, {id: id});
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let data = JSON.stringify(model);
      return this.http.post(`${apiUrl}/reset-password`, data, {headers : headers})
      .map((response: Response) => {
          return response.json();
        });
    }
    // Decrypt the encrypted url.
    decrypturl(url: string) {
      let headers = new Headers();
      headers.append('Content-Type', 'application/json');
      let data = JSON.stringify({url: url});
      return this.http.post(`${apiUrl}/reset-check`, data , {headers : headers})
      .map((response: Response) => {
        return response.json();
      });
    }
}
