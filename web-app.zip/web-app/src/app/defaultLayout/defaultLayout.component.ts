import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
/*import { Global } from './../global';*/

@Component({
    selector: 'my-pages',
    templateUrl: './defaultLayout.component.html'
})
export class DefaultLayoutComponent implements OnInit {

    model: any = {};
    loading = false;
    error = '';
  //  global: any = Global;
    // implement OnInit's `ngOnInit` method
    ngOnInit() {
    }

}
