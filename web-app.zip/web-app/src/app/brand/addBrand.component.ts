import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BrandService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-brand',
    templateUrl: './addBrand.component.html',
    providers: [BrandService],
   })
export class AddBrandComponent implements OnInit {

    brand: any = {};
    loading = false;
    error = '';
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = false;
    constructor(
    private router: Router,
    private BrandService: BrandService) {}

    // implement breadcrumb in `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Brand';
        this.global.layout.breadCrumb = 'Add Brand';
        this.global.layout.cardTilte = 'Dashboard Layout';
    }
    // Add new brand Details.
    addBrand() {
        this.loading = true;
        this.BrandService.addBrand(this.brand)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/brand']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }

        });
    }
    close() {
        this.serviceCalled = false;
    }
}
