import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { WarehouseService } from '../_services/index';
import { WarehouseTypeService } from '../_services/index';
import { StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-warehouse',
    templateUrl: './editWarehouse.component.html',
    providers: [WarehouseService , StatusService , WarehouseTypeService]
})

export class EditWarehouseComponent implements OnInit, OnDestroy {
    warehouse: any = {};
    loading = false;
    error = '';
    id: number;
    private sub: any;
    statuses: any;
    warehousetypes: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = true;
    warehousemastertypes: any;
    hideName = false;
    hideMasters = false;
    constructor(
    private router: Router,
    private WarehouseService: WarehouseService,
    private WarehouseTypeService: WarehouseTypeService,
    private StatusService: StatusService,
    private route: ActivatedRoute) {}

     // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Your Warehouses';
        this.global.layout.breadCrumb = 'Edit Warehouse';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });
        this.WarehouseService.getWarehouses(this.id)
        .subscribe(result => {

            if ( result !== false) {

                this.warehouse = JSON.parse(result);

         if ((this.warehouse.warehouse_type_id === 2) && (this.warehouse.warehouse_master_id)) {
            this.hideMasters = false;
            this.hideName = true;

        } else {
            this.hideMasters = true;
            this.hideName = false;
        }
            }
            return true;
        });
        this.StatusService.listStatusId()
        .subscribe(result => {
            this.statuses = result.content;
        });
        this.WarehouseTypeService.listWarehouseTypeId()
        .subscribe(result => {
            this.warehousetypes = result.content;
        });
    }

    // destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // Edit data into 'nt_warehouse'
    editWarehouse() {
        this.loading = true;
        this.WarehouseService.editWarehouse(this.warehouse)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/warehouse']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }

        });
    }
    close() {
        this.serviceCalled = false;
    }
    showName(warehouse_master_id) {

        if (warehouse_master_id === '4' ) {

            this.hideName = false;

        } else {

            this.hideName = true;

        }
    }
    showMasters(warehouse_type__id) {

        if (warehouse_type__id === '2' ) {

            this.hideMasters = false;
            this.hideName = true;

        }else {

            this.hideName = false;
            this.hideMasters = true;

        }
    }
}
