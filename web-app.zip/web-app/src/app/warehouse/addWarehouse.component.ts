import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WarehouseService } from '../_services/index';
import { WarehouseTypeService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-warehouse',
    templateUrl: './addWarehouse.component.html',
    providers: [WarehouseService , WarehouseTypeService]
})

export class AddWarehouseComponent implements OnInit {
    warehouse: any = {};
    loading = false;
    error = '';
    userData: any;
    retrievedData: any;
    warehousetypes: any;
    warehousemastertypes: any;
    global: any = Global;
    serviceCalled: any = false;
    msg: any = '';
    error_msg = true;
    hideName = false ;
    hideMasters = true;
    constructor(
    private router: Router,
    private WarehouseService: WarehouseService,
    private WarehouseTypeService: WarehouseTypeService) {}

     // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Your Warehouses';
        this.global.layout.breadCrumb = 'Add Warehouse';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.WarehouseTypeService.listWarehouseTypeId()
        .subscribe(result => {
            this.warehousetypes = result.content;

        });
    }
    // Add new data into 'nt_warehouse'
    addWarehouse() {
        this.loading = true;
        this.WarehouseService.addWarehouse(this.warehouse.name, this.warehouse.city, this.warehouse.address1,
            this.warehouse.address2, this.warehouse.pincode, this.warehouse.email, this.warehouse.phone,
            this.warehouse.warehouse_type_id, this.userData.user_id, this.warehouse.status_id, this.warehouse.warehouse_master_id)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/warehouse']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }

        });
    }
    close() {
        this.serviceCalled = false;
    }
    showName(warehouse_master_id) {
        if (warehouse_master_id === '4' ) {
            this.hideName = false;
        }else {
            this.hideName = true;
        }
    }

    showMasters(warehouse_type__id) {

        if (warehouse_type__id === '2' ) {
            this.hideMasters = false;
            this.hideName = true;
        }else {
            this.hideName = false;
            this.hideMasters = true;
        }
    }

}
