import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-about',
    templateUrl: './about.component.html',
})
export class AboutComponent implements OnInit {
  // @maheshPerla: the below link used to trigger the inline edit save  to call the api
  // https://github.com/akveo/ng2-smart-table/issues/284
  settings = {
      columns: {
        id: {
          title: 'ID'
        },
        name: {
          title: 'Full Name'
        },
        username: {
          title: 'User Name'
        },
        email: {
          title: 'Email'
        }
      }
    };
  constructor() {
    // Do stuff
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
    console.log('Hello About');
  }
}
