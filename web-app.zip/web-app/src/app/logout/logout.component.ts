import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../_services/index';

@Component({
    selector: 'my-logout',
    templateUrl: './logout.component.html',
    providers: [AuthenticationService],

})
export class LogoutComponent implements OnInit {

    LastName: string;
    logistics: any = {};
    loading = false;
    error = '';
    constructor(
        private router: Router,
        private authenticationService: AuthenticationService) {}
    // Iterates through the list of champions adding them to the current object
    ngOnInit() {
        this.authenticationService.logout();
        this.router.navigate(['/login']);
    }
}
