import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { SizeTypeService } from '../_services/index';
import { StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-sizetype',
    templateUrl: './editSizeType.component.html',
    providers: [SizeTypeService , StatusService]
})
export class EditSizeTypeComponent implements OnInit, OnDestroy {
    sizetype: any = {};
    loading = false;
    error = '';
    id: number;
    private sub: any;
    categories;
    statuses;
    userData: any;
    retrievedData: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = true;

    constructor(
    private router: Router,
    private SizeTypeService: SizeTypeService,
    private route: ActivatedRoute,
    private StatusService: StatusService) {}
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Size Types';
        this.global.layout.breadCrumb = 'Edit Size Type';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }
        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });

        this.SizeTypeService.getSizeType(this.id)
        .subscribe(result => {
            if ( result !== false) {
                this.sizetype = JSON.parse(result);
            }
            return true;
        });
        this.StatusService.listStatusId()
        .subscribe(result => {
            if ( result !== false) {
                this.statuses = result.content;
            }
        });
    }
    // Destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // Edit size Type from'nt_size_type'.
    editSizeType() {
        this.loading = true;
        this.SizeTypeService.editSizeType(this.sizetype , this.userData)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/size-type']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
  }
  close() {
      this.serviceCalled = false;
  }

}
