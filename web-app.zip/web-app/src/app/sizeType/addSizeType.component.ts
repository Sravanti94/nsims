import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SizeTypeService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-sizetype',
    templateUrl: './addSizeType.component.html',
    providers: [SizeTypeService],
   })
export class AddSizeTypeComponent implements OnInit {

    sizetype: any = {};
    loading = false;
    error = '';
    categories: any;
    userData: any;
    retrievedData: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = true;
    constructor(
    private router: Router,
    private SizeTypeService: SizeTypeService,
    ) {}
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Size Types';
        this.global.layout.breadCrumb = 'Add Size Type';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }
    }
    // Add new size type 'nt_size_type'
    addSizeType() {
        this.global.layout.title = 'Size Type';
        this.global.layout.breadCrumb = 'Add Size Type';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.loading = true;
        this.SizeTypeService.addSizeType(this.sizetype , this.userData)
        .subscribe(result => {
           if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/size-type']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }

        });
    }
    close() {
        this.serviceCalled = false;
    }
}
