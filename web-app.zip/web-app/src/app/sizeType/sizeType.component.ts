import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SizeTypeService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
    selector: 'my-sizetype',
    templateUrl: './sizeType.component.html',
    providers: [SizeTypeService],
})
export class SizeTypeComponent implements OnInit {
    settings = {
        mode: 'external',
        columns: {
            name: {
              title: 'Name',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            },
            status_name: {
              title: 'Status',
              type: 'custom',
              renderComponent: CustomRenderComponent,
            }
      },
        actions: {
            columnTitle: 'Actions',
            add: false,
            edit: true,
            delete: false,
            position: 'right',
        },
        pager: {
            display: true,
            perPage: 10,
        },
        edit: {
          editButtonContent: '<img src="assets/img/edit.png"/>'
        },
        delete: {
          deleteButtonContent: '<img src="assets/img/delete.png"/>'
        },
    };

    sizetype: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    private SizeTypeService: SizeTypeService) { }
    // Iterates through the list adding them to the current object in 'ngoninit' method.
    ngOnInit() {
        this.global.layout.title = 'Size Types';
        this.global.layout.breadCrumb = 'Size Types List';
        this.global.layout.cardTilte = 'Dashboard Layout';

        this.SizeTypeService.listSizeType(this.global.paginator.getRows, this.global.paginator.rows, this.global.paginator.defaultPage)
        .subscribe(result => {

            if ( result !== false) {
                this.sizetype = JSON.parse(result);
                this.source = new LocalDataSource();
                this.source.load(this.sizetype);
            }
            return true;
        });
    }
    // Redirecting to edit sizetype.
    editPreleveur(rowData) {
        this.router.navigate(['/size-type/edit/' + rowData.data.id]);
    }
    // Deleting Data from size type
    deletePreleveur(rowData) {
        if (window.confirm('Are you sure you want to delete?')) {
        this.SizeTypeService.deleteSizetype(rowData.data.id)
        .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
    } else {
        Promise.reject('cancled').then(function(error) {
            return error;
        }, function(error) {
            return error;
        });
    }
}
    // Redirecting data to add size type.
    clicked() {
        this.router.navigate(['/size-type/add']);
    }

}
