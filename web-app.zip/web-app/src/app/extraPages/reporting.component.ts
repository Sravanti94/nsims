import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-reporting',
    templateUrl: './reporting.component.html',
})
export class ReportingComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }
}
