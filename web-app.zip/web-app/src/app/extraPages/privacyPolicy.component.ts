import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-privacy-policy',
    templateUrl: './privacy-policy.component.html',
})
export class PrivacyPolicyComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }
}
