import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-accounting',
    templateUrl: './accounting.component.html',
})
export class AccountingComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }
}
