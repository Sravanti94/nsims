import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-pricing',
    templateUrl: './pricing.component.html',
})
export class PricingComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }
}
