import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-features',
    templateUrl: './features.component.html',
})
export class FeaturesComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }

}
