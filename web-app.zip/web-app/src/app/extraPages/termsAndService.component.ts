import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-terms-and-service',
    templateUrl: './terms-and-service.component.html',
})
export class TermsAndServiceComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }

}
