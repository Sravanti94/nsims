import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-order-fullfillment',
    templateUrl: './order-fullfillment.component.html',
})
export class OrderFullfillmentComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }

}
