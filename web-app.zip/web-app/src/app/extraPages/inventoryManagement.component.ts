import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-inventory-management',
    templateUrl: './inventory-management.component.html',
})
export class InventoryManagementComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }

}
