import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-product-and-listing',
    templateUrl: './product-and-listing.component.html',
})
export class ProductAndListingComponent implements OnInit {
 constructor() {
  }
    // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }
}
