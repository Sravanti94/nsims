import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-partner-withus',
    templateUrl: './partner-withus.component.html',
})
export class PartnerWithUsComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }
}
