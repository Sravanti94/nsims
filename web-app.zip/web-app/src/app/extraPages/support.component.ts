import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-support',
    templateUrl: './support.component.html',
})
export class SupportComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }

}
