import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-contact-us',
    templateUrl: './contact-us.component.html',
})
export class ContactUsComponent implements OnInit {
  constructor() {
  }
  // implement breadcrumb in `ngOnInit` method
  ngOnInit() {
  }

}
