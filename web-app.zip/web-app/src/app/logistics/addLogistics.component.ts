import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LogisticsService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-logistics',
    templateUrl: './addLogistics.component.html',
    providers: [LogisticsService]
})
export class AddLogisticsComponent implements OnInit {
    logistics: any = {};
    loading = false;
    error = '';
    userData: any;
    retrievedData: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = false;
    hidden = true;
    constructor(
    private router: Router,
    private LogisticsService: LogisticsService) {}

    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Your Logistics Partner';
        this.global.layout.breadCrumb = 'Add Logistics Partner';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }
    }
    // Add new logistics'nt_logistics'.
    addLogistics() {
        this.loading = true;
        this.LogisticsService.addLogistics(this.logistics.name, this.logistics.city, this.userData.user_id)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/logistics']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }
        });
    }
    // close error flag.
    close() {
        this.serviceCalled = false;
    }
}
