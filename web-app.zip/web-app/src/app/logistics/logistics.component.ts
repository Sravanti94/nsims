import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LogisticsService } from '../_services/index';
import { LocalDataSource } from 'ng2-smart-table';
import { Global } from './../global';
import { CustomRenderComponent } from '../render/render.component';

@Component({
    selector: 'my-logistics',
    templateUrl: './logistics.component.html',
    providers: [LogisticsService]
})
export class LogisticsComponent implements OnInit {
    settings = {
    mode: 'external',
    columns: {
        name: {
            title: 'Name',
            type: 'custom',
            renderComponent: CustomRenderComponent,
        },
        city: {
            title: 'City',
            type: 'custom',
            renderComponent: CustomRenderComponent,
        },
        status_name: {
            title: 'Status',
            type: 'custom',
            renderComponent: CustomRenderComponent,
       }
    },
    actions: {
        columnTitle: 'Actions',
        add: false,
        edit: true,
        delete: true,
        position: 'right',
    },
    pager: {
        display: false,
        perPage: 10,
    },
    edit: {
        editButtonContent: '<img src="assets/img/edit.png"/>'
    },
    delete: {
        deleteButtonContent: '<img src="assets/img/delete.png"/>'
    },
};
    logistics: any = {};
    loading = false;
    error = '';
    source: LocalDataSource;
    retrievedData: any;
    userData: any;
    global: any = Global;
    totalCount: number;

    constructor(
    private router: Router,
    private LogisticsService: LogisticsService) {}

    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Your Logistics Partner';
        this.global.layout.breadCrumb = 'Logistics Partner List';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.LogisticsService.listLogistics(this.userData.user_id, this.global.paginator.getRows, this.global.paginator.rows,
            this.global.paginator.defaultPage)
        .subscribe(result => {

            if ( result !== false) {
                this.logistics = JSON.parse(result);
                this.source = new LocalDataSource(this.logistics);
            }
            return true;
        });
    }

    // redirecting to edit logistics
    editPreleveur(rowData) {
        this.router.navigate(['/logistics/edit/' + rowData.data.id]);
    }

    // Deleting Data from List
    deletePreleveur(rowData) {
        if (window.confirm('Are you sure you want to delete?')) {
            this.LogisticsService.deleteLogistics(rowData.data.id)
            .subscribe(result => {
            if (result !== false) {
                this.source.remove(rowData.data);
                Promise.resolve();
                return true;
            }
            Promise.resolve();
            return false;
        });
    } else {
        Promise.reject('cancled').then(function(error) {
            return error;
        }, function(error) {
            return error;
        });
    }
}
    // Redirecting to add logistics.
    clicked() {
        this.router.navigate(['/logistics/add']);
    }
}
