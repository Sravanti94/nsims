import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { LogisticsService } from '../_services/index';
import { StatusService } from '../_services/index';
import { Global } from './../global';

@Component({
    selector: 'my-logistics',
    templateUrl: './editLogistics.component.html',
    providers: [LogisticsService , StatusService]
})
export class EditLogisticsComponent implements OnInit, OnDestroy  {
    logistics: any = {};
    loading = false;
    error = '';
    id: number;
    private sub: any;
    userData: any;
    retrievedData: any;
    statuses: any;
    global: any = Global;
    serviceCalled: boolean = false;
    msg: string = '';
    error_msg = false;
    hidden = true;

    constructor(
    private router: Router,
    private LogisticsService: LogisticsService,
    private route: ActivatedRoute,
    private StatusService: StatusService) {}
    // In a real app: load the details here in  `ngOnInit` method
    ngOnInit() {
        this.global.layout.title = 'Your Logistics Partner';
        this.global.layout.breadCrumb = 'Edit Logistics  Partner';
        this.global.layout.cardTilte = 'Dashboard Layout';
        this.retrievedData = localStorage.getItem('currentUser');
        if (this.retrievedData) {
            this.userData = JSON.parse(this.retrievedData);
        }

        this.sub = this.route.params.subscribe(params => {
            this.id = +params['id']; // (+) converts string 'id' to a number
        });

        this.LogisticsService.getLogistics(this.id)
        .subscribe(result => {

            if ( result !== false) {
                this.logistics = JSON.parse(result);
            }
            return true;
        });
        this.StatusService.listStatusId()
        .subscribe(result => {
            this.statuses = result.content;
        });
    }

    // destroying the details on the close of the app :: Garbage collection
    ngOnDestroy() {
        this.sub.unsubscribe();
    }
    // update logistics'nt_logistics'.
    editLogistics() {
        this.loading = true;
        this.LogisticsService.editLogistics(this.logistics, this.userData)
        .subscribe(result => {
            if (result.stat === true) {
                this.msg = result.msg[0];
                this.router.navigate(['/logistics']);
                this.loading = false;
            } else {
                this.serviceCalled = true;
                this.error_msg = true;
                this.msg = result.msg[0];
                this.error = result.stat;
                this.loading = false;
            }

        });
    }
    // close error flag.
    close() {
        this.serviceCalled = false;
    }

}
