import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard, PrimaryAccountAuthGuard } from './_guards/index';


import { DefaultLayoutComponent } from './defaultLayout/defaultLayout.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { RegisterComponent } from './register/register.component';
import { FeaturesComponent } from './extraPages/features.component';
import { PricingComponent } from './extraPages/pricing.component';
import { ContactUsComponent } from './extraPages/contactUs.component';
import { SupportComponent } from './extraPages/support.component';
import { PartnerWithUsComponent } from './extraPages/partnerWithUs.component';
import { TermsAndServiceComponent } from './extraPages/termsAndService.component';
import { AccountingComponent } from './extraPages/accounting.component';
import { PrivacyPolicyComponent } from './extraPages/privacyPolicy.component';
import { ProductAndListingComponent } from './extraPages/productAndListing.component';
import { InventoryManagementComponent } from './extraPages/inventoryManagement.component';
import { OrderFullfillmentComponent } from './extraPages/orderFullfillment.component';
import { ReportingComponent } from './extraPages/reporting.component';
import { AboutComponent } from './about/about.component';

import { DashboardLayoutComponent } from './dashboardLayout/dashboardLayout.component';
import { SuperAccountComponent } from './sa/superaccount.component';

import { AddCategoryComponent } from './category/addCategory.component';
import { CategoryComponent } from './category/category.component';
import { EditCategoryComponent } from './category/editCategory.component';
import { AddBrandComponent } from './brand/addBrand.component';
import { BrandComponent } from './brand/brand.component';
import { EditBrandComponent } from './brand/editBrand.component';
import { AddSizeTypeComponent } from './sizeType/addSizeType.component';
import { SizeTypeComponent } from './sizeType/sizeType.component';
import { EditSizeTypeComponent } from './sizeType/editSizeType.component';
import { AddSizeTypeCategoryComponent } from './sizeTypeCategory/addSizeTypeCategory.component';
import { SizeTypeCategoryComponent } from './sizeTypeCategory/sizeTypeCategory.component';
import { EditSizeTypeCategoryComponent } from './sizeTypeCategory/editSizeTypeCategory.component';
import { AddProductComponent } from './product/addProduct.component';
import { ProductComponent } from './product/product.component';
import { EditProductComponent } from './product/editProduct.component';
import { AddBrandCategoryComponent } from './brandCategory/addBrandCategory.component';
import { BrandCategoryComponent } from './brandCategory/brandCategory.component';
import { EditBrandCategoryComponent } from './brandCategory/editBrandCategory.component';
import { ProfileComponent } from './profile/profile.component';
import { UsersComponent } from './users/users.component';
import { UserProfileComponent } from './users/userProfile.component';
import { CustomRenderComponent } from './render/render.component';

import { PrimaryAccountComponent } from './pa/primaryaccount.component';
import { AddVendorComponent } from './vendor/addVendor.component';
import { EditVendorComponent } from './vendor/editVendor.component';
import { VendorComponent } from './vendor/vendor.component';
import { AddSellerProductComponent } from './sellerProduct/addSellerProduct.component';
import { SellerProductComponent } from './sellerProduct/sellerProduct.component';
import { EditSellerProductComponent } from './sellerProduct/editSellerProduct.component';
import { AddLogisticsComponent } from './logistics/addLogistics.component';
import { LogisticsComponent } from './logistics/logistics.component';
import { EditLogisticsComponent } from './logistics/editLogistics.component';
import { AddWarehouseComponent } from './warehouse/addWarehouse.component';
import { WarehouseComponent } from './warehouse/warehouse.component';
import { EditWarehouseComponent } from './warehouse/editWarehouse.component';

const routes: Routes = [
	
	{ path: '', canActivate: [AuthGuard], component: DashboardLayoutComponent,
	    children: [
			{ path: 'dashboard/s', component: SuperAccountComponent },
			{ path: 'category', component: CategoryComponent},
			{ path: 'category/add', component: AddCategoryComponent},
			{ path: 'category/edit/:id', component: EditCategoryComponent},
			{ path: 'brand', component: BrandComponent},
			{ path: 'brand/add', component: AddBrandComponent},
			{ path: 'brand/edit/:id', component: EditBrandComponent},
			{ path: 'size-type', component: SizeTypeComponent},
			{ path: 'size-type/add', component: AddSizeTypeComponent},
			{ path: 'size-type/edit/:id', component: EditSizeTypeComponent},
			{ path: 'category-sizetype-mapping', component: SizeTypeCategoryComponent},
			{ path: 'category-sizetype-mapping/add', component: AddSizeTypeCategoryComponent},
			{ path: 'category-sizetype-mapping/edit/:id', component: EditSizeTypeCategoryComponent},
			{ path: 'product', component: ProductComponent},
			{ path: 'product/add', component: AddProductComponent},
			{ path: 'product/edit/:id', component: EditProductComponent},
			{ path: 'category-brand-mapping', component: BrandCategoryComponent},
			{ path: 'category-brand-mapping/add', component: AddBrandCategoryComponent},
			{ path: 'category-brand-mapping/edit/:id', component: EditBrandCategoryComponent},
			{ path: 'profile', component: ProfileComponent },
			{ path: 'users', component: UsersComponent},
			{ path: 'users/profile/:id', component: UserProfileComponent},
			{ path: 'user/profile/:id', component: UserProfileComponent},
		]
	},

	{ path: '', canActivate: [PrimaryAccountAuthGuard], component: DashboardLayoutComponent,
		children: [
  			{ path: 'dashboard/p', component: PrimaryAccountComponent },
  			{ path: 'logistics', component: LogisticsComponent},
			{ path: 'logistics/add', component: AddLogisticsComponent},
			{ path: 'logistics/edit/:id', component: EditLogisticsComponent},
			{ path: 'warehouse/add', component: AddWarehouseComponent},
			{ path: 'warehouse', component: WarehouseComponent},
			{ path: 'warehouse/edit/:id', component: EditWarehouseComponent},
			{ path: 'your-products', component: SellerProductComponent},
			{ path: 'your-products/add', component: AddSellerProductComponent},
			{ path: 'your-products/edit/:id', component: EditSellerProductComponent},
			{ path: 'vendor/add', component: AddVendorComponent},
			{ path: 'vendor/edit/:id', component: EditVendorComponent},
			{ path: 'vendor', component: VendorComponent},
			{ path: 'profile/p', component: ProfileComponent },
  		]
	},
	// Dfault Layout for pages
	{ path: '', component: DefaultLayoutComponent,
		children: [
			{ path: 'about', component: AboutComponent },
			{ path: 'features', component: FeaturesComponent },
			{ path: 'pricing', component: PricingComponent },
			{ path: 'contact-us', component: ContactUsComponent },
			{ path: 'support', component: SupportComponent },
			{ path: 'partner-with-us', component: PartnerWithUsComponent },
			{ path: 'terms-and-service', component: TermsAndServiceComponent },
			{ path: 'accounting', component: AccountingComponent },
			{ path: 'privacy-policy', component: PrivacyPolicyComponent },
			{ path: 'product-and-listing', component: ProductAndListingComponent },
			{ path: 'inventory-management', component: InventoryManagementComponent },
			{ path: 'order-fullfillment', component: OrderFullfillmentComponent },
			{ path: 'reporting', component: ReportingComponent },
			{ path: 'login', component: LoginComponent },
			{ path: 'update-password/:encrypturl', component: LoginComponent },
		]
	},
	{ path: 'register', component: RegisterComponent},
	{ path: 'logout', component: LogoutComponent},
	{ path: 'CustomRenderComponent', component: CustomRenderComponent },
];

export const routing = RouterModule.forRoot(routes);
